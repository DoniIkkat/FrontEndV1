# 1.2.4
  * update to react 15.5
  * webpack 2.6
  * freeze dependencies
  * refactor reflux examples
  * ES6 class components
  * refactor to eliminate deprecation warnings
  * more plugin updates
  * OVERALL: 35 files changed, 370 lines inserted | 446 lines deleted

# 1.2.3
  * update webpack version to 2.2.0

# 1.2.2
  * navigation items now located into `src/app/config/navigation.json`  

# 1.2.1  
  * voice control redux
  * webpack new loaders syntax
   
# 1.2.0
  * migration to webpack 2 
  * lazy loading
  * react 15.3
  * d3 map widget
  