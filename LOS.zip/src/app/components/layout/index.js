export * from './LayoutActions'

import layoutReducer from './layoutReducer'

export {layoutReducer}