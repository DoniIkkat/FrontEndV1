"use strict";

export default [
{key: "Sukarasa", value: "Sukarasa"},
{key: "Cimone", value: "Cimone"},
{key: "Cikokol", value: "Cikokol"},
{key: "Cibodas", value: "Cibodas"},
{key: "Karawaci", value: "Karawaci"},
{key: "Gembor", value: "Gembor"},
{key: "Cipete", value: "Cipete"},
{key: "Jatake", value: "Jatake"}
]
