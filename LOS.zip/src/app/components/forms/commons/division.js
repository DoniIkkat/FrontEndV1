"use strict";

export default [
    {key: "Service and sales workers", value: "Service and sales workers"},
    {key: "Production and related workers", value: "Production and related workers"},
    {key: "Associate Professionals and Technicians", value: "Associate Professionals and Technicians"},
    {key: "Plant and Machine operators and Assemblers", value: "Plant and Machine operators and Assemblers"},
    {key: "Farmers", value: "Farmers"},
    {key: "Forestry workers and Fishermen", value: "Forestry workers and Fishermen"},
    {key: "Laborers and Unskilled workers", value: "Laborers and Unskilled workers"},
    {key: "CEO-CFO", value: "CEO-CFO"},
    {key: "Upper Manager", value: "Upper Manager"},
    {key: "Middle Manager", value: "Middle Manager"},
    {key: "Employee", value: "Employee"},
    {key: "Civil servant", value: "Civil servant"},
   
];

