"use strict";

export default [
    {key: "Yamaha", value: "Yamaha"},
    {key: "Honda", value: "Honda"},
    {key: "Suzuki motor", value: "Suzuki motor"},
    {key: "Kawasaki", value: "Kawasaki"},
    {key: "Harley-Davidson", value: "Harley-Davidson"},
    {key: "TVS Motor", value: "TVS Motor"},
    {key: "Viva motor", value: "Viva motor"},
    {key: "KTM", value: "KTM"},
    {key: "Kaisar motor", value: "Kaisar motor"},
    {key: "Benelli", value: "Benelli"},
    {key: "Piaggio / Vespa", value: " Piaggio / Vespa"},
    {key: "Minerva", value: "Minerva"},
    {key: "GAZGAS", value: " GAZGAS"},
    {key: "BMW", value: "BMW"}
   
];

