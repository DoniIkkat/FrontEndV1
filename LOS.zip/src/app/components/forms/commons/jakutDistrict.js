"use strict";

export default [
{key: "Koja", value: "Koja"},
{key: "Cilincing", value: "Cilincing"},
{key: "Kelapa Gading", value: "Kelapa Gading"},
{key: "Tanjung Priok", value: "Tanjung Priok"},
{key: "Penjaringan", value: "Penjaringan"},
{key: "Pademangan", value: "Pademangan"}

]
