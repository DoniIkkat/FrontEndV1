"use strict";

export default [
{key: "PAKUALAMAN", value: "PAKUALAMAN"},
{key: "KRATON", value: "KRATON"},
{key: "GONDOMANAN", value: "GONDOMANAN"},
{key: "MANTRIJERON", value: "MANTRIJERON"},
{key: "UMBULHARJO", value: "UMBULHARJO"},
{key: "TEGALREJO", value: "TEGALREJO"},
{key: "SLEMAN", value: "SLEMAN"}
]