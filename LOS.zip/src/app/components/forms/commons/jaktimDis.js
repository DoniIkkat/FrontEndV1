"use strict";

export default [
{key: "MATRAMAN", value: "MATRAMAN"},
{key: "PULO GADUNG", value: "PULO GADUNG"},
{key: "JATINEGARA", value: "JATINEGARA"},
{key: "DUREN SAWIT", value: "DUREN SAWIT"},
{key: "KRAMAT JATI", value: "KRAMAT JATI"},
{key: "MAKASAR", value: "MAKASAR"},
{key: "CIRACAS", value: "CIRACAS"},
{key: "PASAR REBO", value: "PASAR REBO"},
{key: "CIPAYUNG", value: "CIPAYUNG"}

]
