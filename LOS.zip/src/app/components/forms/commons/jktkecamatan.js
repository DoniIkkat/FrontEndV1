"use strict";

export default [
{key: "Gambir", value: "Gambir"},
{key: "Kebon Kelapa", value: "Kebon Kelapa"},
{key: "Cideng", value: "Cideng"},
{key: "Menteng", value: "Menteng"},
{key: "Kemayoran", value: "Kemayoran"},
{key: "Cikini", value: "Cikini"}

]
