"use strict";

export default [
{key: "All New Jazz", value: "All New Jazz"},
{key: "All New Brio", value: "All New Brio"},
{key: "Luxio", value: "Luxio"},
{key: "Civic Hatchback", value: "Civic Hatchback"},
{key: "Mobilio", value: "Mobilio"},
{key: "HR-V", value: "HR-V"},
{key: "CR-V", value: "CR-V"},

]
