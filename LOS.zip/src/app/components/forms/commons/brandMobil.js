"use strict";

export default [
    {key: "Toyota", value: "Toyota"},
    {key: "Honda", value: "Honda"},
    {key: "Suzuki", value: "Suzuki"},
    {key: "Daihatsu", value: "Daihatsu"},
    {key: "Nissan", value: "Nissan"},
    {key: "KIA", value: "KIA"},
    {key: "BMW", value: "BMW"},
    {key: "Isuzu", value: "Isuzu"},
    {key: "Chevrolet", value: "Chevrolet"},
    {key: "Hyundai", value: "Hyundai"},
    {key: "Ferrari", value: "Ferrari"},
    {key: "Mazda", value: " Mazda"},
    {key: "Hino", value: "Hino"},
    {key: "Mitsubishi", value: " Mitsubishi"},
    {key: "Ford", value: "Ford"}
   
];

