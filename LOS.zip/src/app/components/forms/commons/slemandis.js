"use strict";

export default [
{key: "TEMPEL", value: "TEMPEL"},
{key: "TURI", value: "TURI"},
{key: "SEYEGAN", value: "SEYEGAN"},
{key: "MINGGIR", value: "MINGGIR"},
{key: "MOYUDAN", value: "MOYUDAN"},
{key: "KALASAN", value: "KALASAN"},
{key: "PRAMBANAN", value: "PRAMBANAN"},
{key: "GAMPING", value: "GAMPING"},
{key: "PAKEM", value: "PAKEM"},
{key: "CANGKRINGAN", value: "CANGKRINGAN"}
]