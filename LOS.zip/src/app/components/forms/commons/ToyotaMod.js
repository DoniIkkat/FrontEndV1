"use strict";

export default [
{key: "New Avanza", value: "New Avanza"},
{key: "New Veloz", value: "New Veloz"},
{key: "Calya", value: "Calya"},
{key: "NAV1", value: "NAV1"},
{key: "All New Voxy", value: "All New Voxy"},
{key: "Kijang Innova", value: "Kijang Innova"},
{key: "New Sienta", value: "New Sienta"},
{key: "New Alphard", value: "New Alphard"},
{key: "New Vellfire", value: "New Vellfire"}
]
