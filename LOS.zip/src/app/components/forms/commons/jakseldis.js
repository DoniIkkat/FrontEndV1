"use strict";

export default [
{key: "KEBAYORAN BARU", value: "KEBAYORAN BARU"},
{key: "KEBAYORAN LAMA", value: "KEBAYORAN LAMA"},
{key: "PESANGGRAHAN", value: "PESANGGRAHAN"},
{key: "CILANDAK", value: "CILANDAK"},
{key: "JAGAKARSA", value: "JAGAKARSA"},
{key: "PASAR MINGGU", value: "PASAR MINGGU"},
{key: "SETIA BUDI", value: "SETIA BUDI"}

]
