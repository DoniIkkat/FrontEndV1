"use strict";

export default [
{key: "Tangerang", value: "Tangerang"},
{key: "Batuceper", value: "Batuceper"},
{key: "Karawaci", value: "Karawaci"},
{key: "Cibodas", value: "Cibodas"},
{key: "Cipondoh", value: "Cipondoh"},
{key: "Karang Tengah", value: "Karang Tengah"},
{key: "Ciledug", value: "Ciledug"},
{key: "Kosambi", value: "Kosambi"}
]
