"use strict";

export default [
{key: "Sigra", value: "Sigra"},
{key: "Grand New Xenia", value: "Grand New Xenia"},
{key: "Luxio", value: "Luxio"},
{key: "All New Terios", value: "All New Terios"},
{key: "New Sirion", value: "New Sirion"},
{key: "New Ayla", value: "New Ayla"},
{key: "Hi Max", value: "Hi Max"},
{key: "Granmax MB", value: "Granmax MB"},
{key: "Granmax PU", value: "Granmax PU"}
]
