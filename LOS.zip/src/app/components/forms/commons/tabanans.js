"use strict";

export default [
{key: "Tabanan", value: "Tabanan"},
{key: "Kediri", value: "Kediri"},
{key: "Penebel", value: "Penebel"},
{key: "Kerambitan", value: "Kerambitan"},
{key: "Selemadeg", value: "Selemadeg"},
{key: "Salemadeg Utara", value: "Salemadeg Utara"}
]