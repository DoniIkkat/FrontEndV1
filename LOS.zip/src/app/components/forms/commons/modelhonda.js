"use strict";

export default [
    {key: "Honda CMX 500 Rebel", value: "Honda CMX 500 Rebel"},
    {key: "Honda RC213V-S", value: "Honda RC213V-S"},
    {key: "Honda CRF250 Rally", value: "Honda CRF250 Rally"},
    {key: "New CBR250RR", value: "New CBR250RR"},
    {key: "Honda SH150i", value: "Honda SH150i"},
    {key: "All New Scoopy", value: "All New Scoopy"},
    {key: "Honda Beat Street", value: "Honda Beat Street"},
    {key: "Honda Supra GTR150", value: "Honda Supra GTR150"},
    {key: "Honda Vario 150 eSP", value: "Honda Vario 150 eSP"}
   
];

