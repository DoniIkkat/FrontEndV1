"use strict";

export default [
    {key: "GAMBIR", value: "GAMBIR"},
    {key: "TANAH ABANG", value: "TANAH ABANG"},
    {key: "KEMAYORAN", value: "KEMAYORAN"},
    {key: "PASAR REBO", value: "PASAR REBO"},
    {key: "CIPAYUNG", value: "CIPAYUNG"},
    {key: "CIPONDOH", value: "CIPONDOH"},
    {key: "Jakarta Barat", value: "Jakarta Barat"},
    {key: "Jakarta Timur", value: "Jakarta Timur"},
    {key: "TANGERANG", value: "TANGERANG"},
    {key: "MARGAJAYA", value: "MARGAJAYA"},
    {key: "UJUNG PANDANG", value: "UJUNG PANDANG"},
    {key: "Medan", value: "Medan"},
    {key: "Palembang", value: "Palembang"},
    {key: "Surabaya", value: "Surabaya"},
    {key: "Papua", value: "Papua"},
    {key: "Pontianak", value: " Pontianak"},
    {key: "Yogyakarta", value: "Yogyakarta"}
   
];

