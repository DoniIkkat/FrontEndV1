"use strict";

export default [
{key: "TAMAN SARI", value: "TAMAN SARI"},
{key: "TAMBORA", value: "TAMBORA"},
{key: "PALMERAH", value: "PALMERAH"},
{key: "GROGOL PETAMBURAN", value: "GROGOL PETAMBURAN"},
{key: "KEBON JERUK", value: "KEBON JERUK"},
{key: "KEMBANGAN", value: "KEMBANGAN"},
{key: "CENGKARENG", value: "CENGKARENG"}

]
