"use strict";

export default [
    {key: "Naked", value: "Naked"},
    {key: "Full Automatic", value: "Full Automatic"},
    {key: "Sport", value: "Sport"},
    {key: "Classic", value: "Classic"}
   
];

