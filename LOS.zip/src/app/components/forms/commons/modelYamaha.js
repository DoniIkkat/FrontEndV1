"use strict";

export default [
    {key: "New Yamaha Vixion", value: "New Yamaha Vixion"},
    {key: "FREEGO S Version", value: "FREEGO S Version"},
    {key: "All New X-Ride 125", value: "All New X-Ride 125"},
    {key: "MIO Z", value: "MIO Z"},
    {key: "ALL NEW SOUL GT AKS SSS", value: "ALL NEW SOUL GT AKS SSS"},
    {key: "MIO M3 125", value: "MIO M3 125"},
    {key: "MIO S SMART", value: "MIO S SMART"},
    {key: "Yamaha Grand Filano", value: "Yamaha Grand Filano"},
   
];

