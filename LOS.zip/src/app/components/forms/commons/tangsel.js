"use strict";

export default [
{key: "SERPONG", value: "SERPONG"},
{key: "SERPONG UTARA", value: "SERPONG UTARA"},
{key: "SETU", value: "SETU"},
{key: "CIPUTAT", value: "CIPUTAT"},
{key: "CIPUTAT TIMUR", value: "CIPUTAT TIMUR"},
{key: "PAMULANG", value: "PAMULANG"},
{key: "PONDOK AREN", value: "PONDOK AREN"},
{key: "Ciledug", value: "Ciledug"},
{key: "Pondok Aren", value: "Pondok Aren"}
]
