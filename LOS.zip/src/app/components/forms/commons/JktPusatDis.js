"use strict";

export default [
{key: "Gambir", value: "Gambir"},
{key: "Tanah Abang", value: "Tanah Abang"},
{key: "SENEN", value: "SENEN"},
{key: "Menteng", value: "Menteng"},
{key: "Kemayoran", value: "Kemayoran"},
{key: "CEMPAKA PUTIH", value: "CEMPAKA PUTIH"}

]
