"use strict";

export default [
    {key: "Hatchback", value: "Hatchback"},
    {key: "Sedan", value: "Sedan"},
    {key: "SUV", value: "SUV"},
    {key: "MPV", value: "MPV"},
    {key: "Coupe", value: "Coupe"},
    {key: "Convertible", value: "Convertible"},
    {key: "Pickup", value: "Pickup"},
    {key: "Van", value: "Van"},
    {key: "Jeep", value: "Jeep"}
   
];

