"use strict";

export default [
{key: "DENPASAR UTARA", value: "DENPASAR UTARA"},
{key: "DENPASAR BARAT", value: "DENPASAR BARAT"},
{key: "DENPASAR TIMUR", value: "DENPASAR TIMUR"},
{key: "DENPASAR SELATAN", value: "DENPASAR SELATAN"}
]
