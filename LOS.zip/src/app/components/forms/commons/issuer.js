"use strict";

export default [
    {key: "BCA", value: "BCA"},
    {key: "CIMB Niaga", value: "CIMB Niaga"},
    {key: "BTPN", value: "BTPN"},
    {key: "OCBC NISP", value: "OCBC NISP"},

    // {key: "Citibank N.A", value: "Citibank N.A"},
    // {key: "Pan Indonesia Bank Ltd. Tbk", value: "Pan Indonesia Bank Ltd. Tbk"},
    // {key: "Bank Bukopin Tbk", value: "Bank Bukopin Tbk"}, 
    // {key: "Bank Danamon Indonesia Tbk", value: "Bank Danamon Indonesia Tbk"}, 
    // {key: "Bank ICB Bumiputera", value: "Bank ICB Bumiputera"},
    // {key: "Bank Mandiri (Persero) Tbk", value: "Bank Mandiri (Persero) Tbk"},
    // {key: "Bank Internasional Indonesia Tbk", value: "Bank Internasional Indonesia Tbk"},
    // {key: "Bank Mega Tbk", value: "Bank Mega Tbk"},
    // {key: "Bank Negara Indonesia Syariah", value: " Bank Negara Indonesia Syariah"},
    // {key: "Bank Permata Tbk", value: "Bank Permata Tbk"}, 
    // {key: "Bank Mayapada", value: "Bank Mayapada"},
    // {key: "Bank HSBC Indonesia", value: "Bank HSBC Indonesia"},
    // {key: "Shinhan Indo Finance", value: "Shinhan Indo Finance"}
   
   
];

