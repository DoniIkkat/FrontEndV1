"use strict";

export default [
    {key: "DKI Jakarta", value: "DKI Jakarta"},
    {key: "Banten", value: "Banten"},
    {key: "Yogyakarta", value: "Yogyakarta"},
    {key: "Lampung", value: "Lampung"},
    {key: "Aceh", value: "Aceh"},
    {key: "Bali", value: "Bali"},
    {key: "Bengkulu", value: "Bengkulu"},
    {key: "Gorontalo", value: "Gorontalo"},
    {key: "Jambi", value: "Jambi"},
    {key: "Maluku", value: "Maluku"},
    {key: "Papua", value: "Papua"},
    {key: "Kalimantan Tengah", value: "Kalimantan Tengah"},
    {key: "Kalimantan Timur", value: "Kalimantan Timur"},
    {key: "Kalimantan Barat", value: "Kalimantan Barat"},
    {key: "Kalimantan Selatan", value: "Kalimantan Selatan"},
    {key: "Kalimantan Utara", value: "Kalimantan Utara"},
    {key: "Sulawesi Selatan", value: "Sulawesi Selatan"},
    {key: "Sulawesi Timur", value: "Sulawesi Timur"},
    {key: "Sulawesi Tengah", value: "Sulawesi Tengah"},
    {key: "Jawa Tengah", value: "Jawa Tengah"},
    {key: "Jawa Timur", value: "Jawa Timur"},
    {key: "Jawa Barat", value: "Jawa Barat"}
];