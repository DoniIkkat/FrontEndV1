"use strict";

export default [
    {key: "Suzuki GSX R150", value: "Suzuki GSX R150"},
    {key: "Suzuki GSX 150 Bandit", value: "Suzuki GSX 150 Bandit"},
    {key: "Suzuki GSX S150", value: "Suzuki GSX S150"},
    {key: "All New Satria F150", value: "All New Satria F150"},
    {key: "Suzuki New Smash FI", value: "Suzuki New Smash FI"},
    {key: "Suzuki Address FI", value: "Suzuki Address FI"},
    {key: "Suzuki Address Playful", value: "Suzuki Address Playful"},
    {key: "Suzuki NEX II", value: "Suzuki NEX II"}
   
];

