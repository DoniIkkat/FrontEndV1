"use strict";

export default [
    {key: "Ninja 250SL", value: " Ninja 250SL"},
    {key: "Ninja 250 2019", value: "Ninja 250 2019"},
    {key: "Kawasaki Z250", value: "Kawasaki Z250"},
    {key: "Kawasaki Z800", value: "Kawasaki Z800"},
    {key: "Kawasaki ER-6n", value: "Kawasaki ER-6n"},
    {key: "All New Scoopy", value: "All New Scoopy"},
    {key: "Ninja 300", value: "Ninja 300"},
    {key: "Versys 1000", value: "Versys 1000"},
    {key: "Versys 650", value: "Versys 650"},
    {key: "Kawasaki Z125 Pro", value: "Kawasaki Z125 Pro"},
    {key: "Versys 1000", value: "Versys 1000"},
    {key: "Kawasaki D-Tracker", value: "Kawasaki D-Tracker"},
    {key: "Versys 1000", value: "Versys 1000"}
   
];

