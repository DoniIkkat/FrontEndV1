require('smartadmin-plugins/notification/SmartNotification.min.js');

export function smallBox(data, cb) {
  $.smallBox(data, cb)
}

export function bigBox(data, cb) {
  $.bigBox(data, cb)
}


export function SmartMessageBox(data, cb) {
  $.SmartMessageBox(data, cb)
}


