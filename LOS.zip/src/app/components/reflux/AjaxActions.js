import Reflux from 'reflux'


const AjaxActions = Reflux.createActions({
    contentLoaded: {}
});

export default AjaxActions