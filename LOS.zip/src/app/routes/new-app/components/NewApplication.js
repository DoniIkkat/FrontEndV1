import React from 'react' 

import {connect} from 'react-redux'
import {postApp} from '../../forms/components/wizards/actions/allActions'
import {updateLoan, postLoan, postData} from '../../forms/components/wizards/actions/loanActions'
import {updatePersonal} from '../../forms/components/wizards/actions/personalActions'
import {updateAddress} from '../../forms/components/wizards/actions/addressAction'
import {updateCompany, updateCompanyAddress} from '../../forms/components/wizards/actions/businessAction'
import {updateBank, updateCreditCard} from '../../forms/components/wizards/actions/bankAction'
import {updateSourceIncome, updateMonthlyIncome, updateMonthlyExpense} from '../../forms/components/wizards/actions/financialAction'
import {updateFamily} from '../../forms/components/wizards/actions/familyAction'
import {updateCollateral} from '../../forms/components/wizards/actions/collateralAction'

import BigBreadcrumbs from '../../../components/navigation/components/BigBreadcrumbs'  
import BasicWizardWidget from '../../forms/components/wizards/BasicWizardWidget';

class NewApplication extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      marital_status: null,
      valueCC: false,
      all: {
        loan: {
          loanProductId: "Empty",
          purpose: "Empty",
          loanAmount: {
            value: 0,
            currency: "IDR"
          },
          tenor: "Empty"
        },
        personal: {
            dateOfBirth: "Empty",
            education: "Empty",
            email: "Empty",
            fullName: "Empty",
            gender: "Empty",
            houseLocation: "Empty",
            houseOwnership: "Empty",
            idNum: "Empty",
            idType: "Empty",
            landlinePhone: "Empty",
            maritalStatus: "Empty",
            mobile: "Empty", 
            placeOfBirth: "Empty",
            vehicle: "Empty"
        },
        addressMain: {
            city: "Empty", 
            collateralYearEnd: "Empty",
            currentAddress: "Empty",
            district: "Empty",  
            postalCode: "Empty",
            province: "Empty",
            usedYearEnd: "Empty",
            usedYearSince: "Empty"
        },
        addressAdditional: {
            city: "Empty", 
            collateralYearEnd: "Empty",
            currentAddress: "Empty",
            district: "Empty",  
            postalCode: "Empty",
            province: "Empty",
            usedYearEnd: "Empty",
            usedYearSince: "Empty"
        },
        family: {
            emergencyAddress: {
              city: "Empty",
              currentAddress: "Empty",
              district: "Empty", 
              postalCode: "Empty",
              province: "Empty"
            },
            emergencyContactMobile: "Empty",
            emergencyContactPersonName: "Empty", 
            spouseDateOfBirth: "Empty",
            spouseIdNum: "Empty",
            spouseIdType: "Empty",
            spouseMobile: "Empty",
            spouseName: "Empty",
            spousePlaceOfBirth: "Empty"
        },
        business: {
          businessIndustry: "Empty",
          companyAddress: {
            city: "Empty",
            currentAddress: "Empty",
            district: "Empty", 
            postalCode: "Empty",
            province: "Empty"
          },
          companyName: "Empty",
          division: "Empty",
          employmentkDuration: "Empty",
          position: "Empty",
          totalNoEmployees: "Empty"
        },
        finance: [{
            incomeSource: "Empty",
            monthlyExpense: {
                currency: "Empty",
                value: "Empty"
            },
            monthlyIncome: {
                currency: "Empty",
                value: "Empty"
            }
        }],
        bank: {
            account: {
                accountNumber: "Empty",
                accountType: "Empty", 
                nameOfBank: "Empty"
            },
            creditCardList:[
            {
                creditCardNo: "Empty",
                issuer: "Empty",
                type: "Empty"
            }]
        },
        collateral: {
            collateralTypeId: 0
        }
      }
    }
  }

  componentDidMount(){
    // this.onGetData()
  }

  onChangeCreditCard(e){
    console.log("Bank",e.target.value)
    if(e.target.value==1)
        this.setState({
            valueCC: true
        });
    else {
        this.setState({
            valueCC: false
        });
    }
}

  onSaveDraft(){
    console.log("SAVE DRAFT",this.props.all)
    this.props.loanPost(this.props.all)
    this.onGetData()
  }

  onSubmitData(){
    console.log("ON SUBMIT", this.props.all) 
    this.props.dataPost(this.props.all);
  }

  onHandleMaritalStatus(e){
    this.setState({
      marital_status: e
    })
  }

  onGetData(){ 
    this.setState(prevState =>({
      all: {
        ...prevState.all,
        loan: {
          ...prevState.all.loan,
          ...this.props.all.loan,
        },
        personal:{
          ...prevState.all.personal,
          ...this.props.all.personal
        },
        addressMain: {
          ...prevState.all.addressMain,
        },
        addressAdditional: {
          ...prevState.all.addressAdditional
        },
        family: {
          ...prevState.all.family,
          ...this.props.all.family
        },
        business: {
          ...prevState.all.business,
          ...this.props.all.business
        },
        finance: {
            ...prevState.all.finance,
            ...this.props.all.finance
        },
        bank: {
            ...prevState.all.bank,
            ...this.props.all.bank
        },
        collateral: {
            collateralTypeId: 0
        }
      }
    }),
    console.log("onGetData", this.state.all))
  }
  
  render() {
    console.log("props.all", this.props.all)
    // console.log("props.all.Bank: ",this.props.all.bank)
    // console.log("state.bank: ", this.state.all.bank)
    return (
        <div id="content">
        
        <div className="row">
          <BigBreadcrumbs items={['New Application']}
            className="col-xs-12 col-sm-7 col-md-7 col-lg-4"/> 
          <div className="col-xs-4 col-sm-4 col-md-4 col-log-4">
              <a className="btn btn-info btn-lg" 
                onClick={this.onSaveDraft.bind(this)} 
                // href="#/application"
              >
                Save as Draft</a>
            </div>
        </div>
        
        <BasicWizardWidget
          marital_status = {this.state.marital_status}
          maritalStatus_update = {this.onHandleMaritalStatus.bind(this)}
          onGetData = {this.onGetData.bind(this)}
          onSubmitData = {this.onSubmitData.bind(this)}
          appPost = {this.props.appPost.bind(this)}
          valueCC = {this.state.valueCC}
          onChangeCreditCard = {this.onChangeCreditCard.bind(this)}

          all = {this.state.all}
          loan = {this.props.all.loan}
          business = {this.props.all.business}
          bank = {this.props.all.bank}
          financial = {this.props.all.financial}
          loanUpdate = {this.props.loanUpdate.bind(this)}
          personal = {this.props.all.personal}
          personalUpdate = {this.props.personalUpdate.bind(this)}
          addressUpdate = {this.props.addressUpdate.bind(this)}
          companyUpdate = {this.props.companyUpdate.bind(this)}
          companyAddressUpdate = {this.props.companyAddressUpdate.bind(this)}
          bankUpdate = {this.props.bankUpdate.bind(this)}
          creditCardUpdate = {this.props.creditCardUpdate.bind(this)}
          familyUpdate = {this.props.familyUpdate.bind(this)}
          financialUpdate = {this.props.financialUpdate.bind(this)}
          collateralUpdate = {this.props.collateralUpdate.bind(this)}
        />

      </div>
    )
  }
}


const mapStateToProps = state => ({
  all: state.all
})

const mapActionToDispatch = {
  loanUpdate: updateLoan,
  loanPost: postLoan,
  dataPost: postData,

  appPost: postApp,
  
  personalUpdate: updatePersonal,

  addressUpdate: updateAddress,

  companyUpdate: updateCompany,
  companyAddressUpdate: updateCompanyAddress,

  bankUpdate: updateBank,
  creditCardUpdate: updateCreditCard,

  financialUpdate: updateSourceIncome,
  financialMonthlyIncome: updateMonthlyIncome,
  financialMonthlyExpense: updateMonthlyExpense,

  familyUpdate: updateFamily,

  collateralUpdate: updateCollateral

}

export default connect(mapStateToProps, mapActionToDispatch)(NewApplication)