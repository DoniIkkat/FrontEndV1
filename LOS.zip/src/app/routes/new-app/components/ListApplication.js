import React from 'react' 
import {url} from '../../../config/baseUrl'

import BigBreadcrumbs from '../../../components/navigation/components/BigBreadcrumbs'  
import Datatable from '../../../components/tables/Datatable'
import JarvisWidget from '../../../components/widgets/JarvisWidget'

const pageNumb = 2;
const pageSize = 100;
var loans = ''
export default class ListApplication extends React.Component {
  constructor(){
    super();
    this.state ={ 
      data: []
    };
  }

  componentDidMount(){
    fetch(`${url}/loan/application/v1/applicant-list/?pageSize=${pageSize}`, 
        {
            method: 'GET',
            headers: {
                Authorization: 'Bearer '+localStorage.getItem('token')
            }, 
        })
        .then(response => response.json())
        .then(appList => { 
            this.setState({
              data: appList.content
            }) 
        })
  }

  render() {
    console.log(this.state.data)
    return (
      <div id="content"> 
        <div className="row">
          <BigBreadcrumbs items={['Application']}
            className="col-xs-6 col-sm-7 col-md-7 col-lg-8"/> 
            <div className="col-xs-4 col-sm-4 col-md-4 col-log-4">
              <a href="#/new-app" className="btn btn-info btn-lg ">New Application</a>
            </div>
            {/* {console.log("State.data",this.state.data)} */}
            
        </div> 

         <div className="row">
                <article className="col-sm-12">

                <JarvisWidget editbutton={false} color="darken">
                <header><span className="widget-icon"> <i className="fa fa-table"/> </span> <h2>Data</h2></header>
                <div>
                  <div className="widget-body no-padding">
                    <div className="table-responsive">
                      <table className="table table-bordered">
                        <tr>
                          <th>Name</th>
                          <th>Loan Product</th>
                          <th>Loan Amount</th>
                          <th>Date</th>
                        </tr>
                        {
                          this.state.data.map(function(content){
                            // {console.log("data ",content)}
                            return (
                              <tr key={content.loanApplicationId}>
                                <td>{content.customerFullName}</td>
                                <td>{content.loanProductName}</td>
                                <td>{content.loanAmount}</td>
                                <td>{content.applyDate}</td>
                              </tr>
                              // <li>{content.customerFullName}</li>
                            )
                          })
                        }
                      </table>
                    </div>

                    <Datatable
                    options={{
                      // ajax: 'assets/api/tables/datatables.standard.json',
                      // ajax: 'json/applyloan.json',
                      columns: [{data: "customerFullName"}, {data: "name"}, {data: "phone"}, {data: "company"}]
                    }}
                    paginationLength={true} className="table table-striped table-bordered table-hover"
                    width="100%"
                    > 
                    <thead>
                    <tr>
                      <th data-hide="phone">ID</th>
                      <th data-class="expand"><i
                        className="fa fa-fw fa-user text-muted hidden-md hidden-sm hidden-xs"/>
                        Name
                      </th>
                      <th data-hide="phone"><i
                        className="fa fa-fw fa-phone text-muted hidden-md hidden-sm hidden-xs"/>
                        Phone
                      </th>
                      <th>Company</th> 
                    </tr>
                    </thead>
                  </Datatable>
                    
                    {/* 
                    <Datatable
                    options={{
                      ajax: 'assets/api/tables/datatables.standard.json',
                      // ajax: 'json/applyloan.json',
                      columns: [{data: "id"}, {data: "name"}, {data: "phone"}, {data: "company"}]
                    }}
                    paginationLength={true} className="table table-striped table-bordered table-hover"
                    width="100%"
                    > 
                    <thead>
                    <tr>
                      <th data-hide="phone">ID</th>
                      <th data-class="expand"><i
                        className="fa fa-fw fa-user text-muted hidden-md hidden-sm hidden-xs"/>
                        Name
                      </th>
                      <th data-hide="phone"><i
                        className="fa fa-fw fa-phone text-muted hidden-md hidden-sm hidden-xs"/>
                        Phone
                      </th>
                      <th>Company</th> 
                    </tr>
                    </thead>
                  </Datatable> */}
                  </div>
                </div>
              </JarvisWidget>
                </article>
            </div>
        
      </div>
    )
  }
}