/**
 * Created by griga on 11/30/15.
 */

import React from 'react'
import {connect} from 'react-redux'

import Stats from '../../../components/common/Stats' 
import {apiFetch} from '../../auth/actions/authAction'

import MorrisCharts from "../../graphs/containers/MorrisCharts"
import ChartJs from "../../graphs/containers/ChartJs"
import NormalTables from "../../tables/containers/NormalTables"
import Msg from "../../../components/i18n/Msg"

class Dashboard extends React.Component {
  getStats() {
    return {
      time: '1 Month'
      }
  }

  componentDidMount(){
    this.props.fetchToken();
    // console.log("token = ", localStorage.getItem('token'));
    // console.log(this.props.auth)
  }
  
  render() {
    // const time = this.getStats()
    return (
      <div id="content">
        
        <div className="row">
          <div className="well well-sm bg-color-darken txt-color-white text-center">
            {/* <BigBreadcrumbs items={['Dashboard']}
            className="col-xs-12 col-sm-7 col-md-7 col-lg-4"/>  */}
            <h1>
              <Msg phrase="Dashboard"
              className="col-xs-12 col-sm-7 col-md-7 col-lg-4"/> 
            </h1> 
          </div> 
        </div>

        {/* <WidgetGrid> */}
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-6 col-lg-3">
              <div className="well well-sm bg-color-darken txt-color-white text-center">
                <h5>
                  <Msg phrase="Timespan"/>
                </h5> 
                <select className="form-control" name="Time">
                  <option value="">1 Month</option> 
                  <option>2 Month</option>
                  <option>3 Month</option>
                  <option>6 Month</option>
                  <option>12 Month</option>
                  <option>24 Month</option>
                </select>
              </div>
          </div>
          <Stats />
        </div>

          <div className="row">
             <article className="col-xs-12 col-sm-12 col-md-12 col-lg-9">
              <h4><Msg phrase="Bot Progress"/></h4>  
              {/* <LiveFeeds /> */}
              <MorrisCharts />

            </article>
            <article className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
              <h4><Msg phrase="Channel Usage"/></h4> 
              <ChartJs />              
              {/* <BirdEyeWidget /> */}
            </article>
          </div>


          <div className="row"> 

            <article className="col-sm-12 col-md-6 col-lg-6">
              {/* <ChatWidget />
              <FullCalendarWidget />  */}
              <NormalTables
                title="Top 5 Loan Product"
              />

            </article>

            <article className="col-sm-12 col-md-12 col-lg-6"> 
               {/* <BirdEyeWidget />  
              <TodoWidget /> */}
              <NormalTables 
                title="Top Loan Range Size"
              />
            </article>
          </div>

        {/* </WidgetGrid> */}

      </div>
    )
  }
 
}

const mapStateToProps = state => ({
  auth: state.auth
})

const mapActionToDispatch = {
  fetchToken: apiFetch
}

export default connect(mapStateToProps, mapActionToDispatch)(Dashboard)