import React from 'react'

import {Alert} from 'react-bootstrap'

import {Stats, BigBreadcrumbs, WidgetGrid, JarvisWidget}  from '../../../components'
import Msg from '../../../components/i18n/Msg';

export default class NormalTables extends React.Component {
  render() {
    return (
      <div id="content">
        {/* <div className="row">
          <BigBreadcrumbs items={['Tables', 'Normal Tables']} icon="fa fa-fw fa-table"
                          className="col-xs-12 col-sm-7 col-md-7 col-lg-4"/>
          <Stats />
        </div> */} 
          <div className="row">
            <article className="col-sm-12">

              <JarvisWidget editbutton={false} color="blueDark">
                <header>
                  <span className="widget-icon"> <i className="fa fa-table"/> </span>

                  <h2><Msg phrase={this.props.title}/></h2>
                </header>
                <div>
                  <div className="widget-body">

                    <div className="table-responsive">

                      <table className="table table-bordered">
                        <thead>
                        <tr>
                          <th>No.</th>
                          <th>Column name</th>
                          <th>Column name</th>
                          <th>Column name</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                          <td style={{width: "10%"}}>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        <tr>
                          <td>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        <tr>
                          <td>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        <tr>
                          <td>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        <tr>
                          <td>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        <tr>
                          <td>Row 1</td>
                          <td>Row 2</td>
                          <td>Row 3</td>
                          <td>Row 4</td>
                        </tr>
                        </tbody>
                      </table>

                    </div>

                  </div>
                </div>
              </JarvisWidget>
 

            </article> 
          </div> 
      </div>
    )
  }
}