import React from 'react'
import DropzoneInput from '../../../../components/forms/inputs/DropzoneInput'

export default class CollateralRealEstate extends React.Component{ 
    state = { 
        collateralTypeId: 3,
        parameters: {}
      };

    onParse(e){ 
        var str = e.target.value
        str = str.replace(/,/g, "")
        var parsedNumb = parseInt(str)
        const prodId = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [prodId]: parsedNumb
            }
        }),
            this.onReturnData.bind(this)
        )
      }

      onDate(e){ 
        const value = `${e.target.value}T00:00:00.000+07:00` 
        const personalInput = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [personalInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
      }

      onChangeEstate(e){
        const value = e.target.value;
        const prodId = e.target.name;
        this.setState(prevState =>({
            parameters: {
                ...prevState.parameters,
                [prodId]: value
            }
        }),
            this.onReturnData.bind(this)
        ) 
      }

      onReturnData(){ 
          console.log(this.state)
          this.props.collateralList(this.state)
      }

    render(){
        let maxOffset = 50;
        let thisYear = (new Date()).getFullYear();
        let allYears = [];
        for(let x = 0; x <= maxOffset; x++) {
            allYears.push(thisYear - x)
        }
    
        const CyearList = allYears.map((x) => {return(<option key={x}>{x}</option>)});
        return(
            <div>
                <br/>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Real Estate</b></h4>
                                <select className="form-control input-lg"
                                            data-smart-validate-input="" data-required=""
                                            name="realestate" 
                                            onChange={this.onChangeEstate.bind(this)}
                                            defaultValue={"0"}>
                                            <option value="0" disabled={true}>Type of Real Estate</option>    
                                            <option>House</option>
                                            <option>Villa</option>
                                            <option>Apartment</option>  
                                        </select> 
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="condition" style={{textAlign:"left"}}><b>Condition</b></h4>
                                <textarea rows="3" placeholder="Describe the condition" 
                                    className="form-control input-md" required  data-message="Please specify this condition"
                                    id="example-textarea" data-minlength="10" data-maxLength="255"
                                    name="condition"
                                    onChange={this.onChangeEstate.bind(this)}>
                                    </textarea>
                            </div>
                        </div>
                    </div>
                </div>     
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="yearbuild" style={{textAlign:"left"}}><b>Year Build</b></h4>
                                <select className="form-control input-lg"
                                            data-smart-validate-input="" data-required=""
                                            name="year"
                                            onChange={this.onParse.bind(this)}
                                            defaultValue={"0"}>
                                            <option value="0" disabled="true">Select Year</option>
                                            {CyearList}
                                      </select>    
                            </div>
                        </div>
                    </div>
                </div>                
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Rooms</b></h4>
                                  <input className="form-control input-lg"
                                            placeholder="Rooms" type="number" min="0"
                                            data-smart-validate-input="" data-required="" 
                                            name="numrooms"
                                            onChange={this.onParse.bind(this)}
                                            data-message="Please specify the room number"/>
                            </div>
                        </div>
                    </div>
                </div>            
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="inputAddress" style={{textAlign:"left"}}><b>Address</b></h4>
                                <textarea rows="4" placeholder="Full Address" 
                                    className="form-control input-md" required  data-message="Please specify your address"
                                    id="example-textarea" data-minlength="10" data-maxLength="255"
                                    name="address"
                                    onChange={this.onChangeEstate.bind(this)}
                                    >
                                    </textarea>
                            </div>
                        </div>
                    </div>
                </div>     
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Size</b></h4>
                                <input className="form-control input-lg"
                                            placeholder="Total Area, L * W, in meter squaresize" type="number"
                                            data-smart-validate-input="" data-required="" 
                                            name="size"
                                            onChange={this.onParse.bind(this)}
                                            data-message="please specify the area's size" min="0"/>
                                            <div className="note">
                                <strong>Note:</strong> format text input in  m^2.
                            </div>
                            </div>
                        </div>
                    </div>
                </div>       
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Proof of Ownership</b></h4>
                                 <input className="form-control input-lg"
                                            placeholder="Proof of Ownership" type="text"
                                            data-smart-validate-input="" data-required="Please specify the Ownership" 
                                            name="certnumowner"
                                            onChange={this.onChangeEstate.bind(this)}
                                            data-message="Please specify the Ownership"/>
                            </div>
                        </div>
                    </div>
                </div> 
                <div className="row">
                 <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                 <header>
                 
                  <h2>UPLOAD</h2>

                </header>


                  {/* widget content */}
                  <div className="widget-body">

                    <DropzoneInput options={{
                      addRemoveLinks: true,
                      maxFilesize: 0.5,
                      dictDefaultMessage: '<span class="text-center"><span class="font-lg visible-xs-block visible-sm-block visible-lg-block"><span class="font-lg"><i class="fa fa-caret-right text-danger"></i> Drop files <span class="font-xs">to upload</span></span><span>&nbsp&nbsp<h4 class="display-inline"> (Or Click)</h4></span>',
                      dictResponseError: 'Error uploading file!'
                    }}>
                      <form action="/upload" className="dropzone" id="file"/>
                    </DropzoneInput>
                    <span className="widget-icon"> <i className="fa fa-cloud-upload text-muted mb-3"/> </span>
                    </div>
                    
                 </div>      
                </div>                                                                
            </div>
            
        )
        
    }
}