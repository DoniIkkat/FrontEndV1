import React from 'react'
import DropzoneInput from '../../../../components/forms/inputs/DropzoneInput'
import TypeVehicle from './TypeVehicle';

export default class CollateralVehicle extends React.Component{ 
    constructor(props){
        super(props)
        this.state = {
            collateralTypeId: 1,
            valueCv: '',
        }
    }

    onParse(e){ 
        var str = e.target.value
        str = str.replace(/,/g, "")
        var parsedNumb = parseInt(str)
        const prodId = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [prodId]: parsedNumb
            }
        }),
            this.onReturnData.bind(this)
        )
      }

      onDate(e){ 
        const value = `${e.target.value}T00:00:00.000+07:00` 
        const personalInput = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [personalInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
      }

      onVehicle(e){
        const value = e.target.value;
        const prodId = e.target.name;
        this.setState(prevState =>({
            parameters: {
                ...prevState.parameters,
                type: this.state.valueCv,
                [prodId]: value
            }
        }),
            this.onReturnData.bind(this)
        ) 
      }

      onReturnData(){ 
          console.log(this.state)
          this.props.collateralList(this.state)
      }

    OnChangeVehicle(event){
        this.setState({
            valueCv: event.target.value,
            parameters: {}
        });
    }

    render(){
        let  maxOffset = 50;
        let thisYear = (new Date()).getFullYear();
        let allYears = [];
        for(let x = 0; x <= maxOffset; x++) {
            allYears.push(thisYear - x)
        }
    
        const yearList = allYears.map((x) => {return(<option key={x}>{x}</option>)});
        return(
            <div>
                <br/>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Vehicle</b></h4>
                            <input className="col-xs-4 col-md-12 input-lg" 
                                         required data-message-required="Please Choose option" name="vehicle" 
                                         onChange={this.OnChangeVehicle.bind(this)} value={this.state.valueCv} 
                                        placeholder="Choose Type ..." type="text" list="listCv"/>
                                         <datalist id="listCv">
                                            <option value="Car">Car</option>
                                            <option value="Motorcyle">Motorcyle</option>
                                        </datalist>
                            </div>
                        </div>
                    </div>
                </div>     
                <TypeVehicle  
                    DivState={this.state.valueCv}
                    onVehicle={this.onVehicle.bind(this)}
                />
                <br/>      
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4 className="input" style={{textAlign:"left"}}><b>Year</b></h4>
                                    <select className="form-control input-lg"
                                        data-smart-validate-input="" data-required=""
                                        name="year"
                                        onChange={this.onParse.bind(this)}
                                        defaultValue={"0"}>
                                        <option value="0" disabled="true">Select Year</option>
                                          {yearList}
                                        </select>    
                            </div>
                        </div>
                    </div>
                </div>     
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Mileage</b></h4>
                            <input className="form-control input-lg" min="0"
                                    placeholder="Length of Mileage"
                                    type="number" 
                                    name="mileage" 
                                    onChange={this.onParse.bind(this)}
                                    required
                                    data-smart-validate-input="" data-required=""
                                    data-message="Please specify the condition of the real estate"
                                /> 
                                <div className="note">
                                   <strong>Note:</strong> format text input in miles.
                            </div>              
                          </div>
                        </div>
                    </div>
                </div>       
                <div className="row">
                 <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                 <header>
                 
                  <h2>UPLOAD</h2>

                </header>


                  {/* widget content */}
                  <div className="widget-body">

                    <DropzoneInput options={{
                      addRemoveLinks: true,
                      maxFilesize: 0.8,
                      dictDefaultMessage: '<span class="text-center"><span class="font-lg visible-xs-block visible-sm-block visible-lg-block"><span class="font-lg"><i class="fa fa-caret-right text-danger"></i> Drop files <span class="font-xs">to upload</span></span><span>&nbsp&nbsp<h4 class="display-inline"> (Or Click)</h4></span>',
                      dictResponseError: 'Error uploading file!'
                    }}>
                      <form action="/upload" className="dropzone" id="file"/>
                    </DropzoneInput>
                    <span className="widget-icon"> <i className="fa fa-cloud-upload text-muted mb-3"/> </span>
                    </div>
                    
                 </div> 
                </div>                                                        
            </div>
            
        )
        
    }
}
