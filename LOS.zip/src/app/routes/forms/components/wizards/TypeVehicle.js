import React from 'react'
import VehicleMob from './VehicleMob';
import VehicleMot from './VehicleMot';


export default class TypeVehicle extends React.Component{ 
    
    render(){ 

        if(this.props.DivState ==='Car'){
            return(
                <div>
                    <VehicleMob
                        onVehicle = {this.props.onVehicle.bind(this)}
                    />
                </div>                
            );
        } else if(this.props.DivState ==='Motorcyle'){ 
            return(
                <div>
                    <VehicleMot
                        onVehicle = {this.props.onVehicle.bind(this)}
                    />
                    <br/>
                </div>                
            );
        }  else { 
            return <div></div>
        } 

        
    }
}