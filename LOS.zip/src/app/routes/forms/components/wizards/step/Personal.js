import React from 'react'
import NumberFormat from 'react-number-format';

export default class Personal extends React.Component{ 
  constructor(props){
    super(props);
    this.state = { 
      personal: this.props.personal_state
    }
  }

  onDate(e){ 
    const value = `${e.target.value}T00:00:00.000+07:00`
    console.log(value);
    const personalInput = e.target.name;
    this.setState(prevState =>({
      personal: {
          ...prevState.personal,
          [personalInput]: value
        }
    }),
    this.onReturnPersonal.bind(this)
    )
  }
  
  toggleInfo(type) {
    let state = {};
    state[type] = !this.state[type];
    this.setState(state);
    $(this.refs.form)
      .data("bootstrapValidator")
      .disableSubmitButtons(false);
  }

  onMaritalStatus(e){
    const value = e.target.value;  
    this.setState(prevState =>({
      personal: {
          ...prevState.personal,
          maritalStatus: value
        }
    }),
    this.onReturnPersonal.bind(this)
    )
  }

  // onIdNumber(e){
  //   const value = e.target.value;  
  //   this.setState(prevState =>({
  //     personal: {
  //         ...prevState.personal,
  //         IdNumber: value
  //       }
  //   }),
  //   this.onReturnPersonal.bind(this)
  //   )
  // }

  onChangePersonal(e){ 
    const value = e.target.value;
    console.log(e.target.value)
    const personalInput = e.target.name;
    this.setState(prevState =>({
      personal: {
          ...prevState.personal,
          [personalInput]: value
        }
    }),
    this.onReturnPersonal.bind(this)
    )
    console.log(this.state.personal)
  } 

  onReturnPersonal(){
    this.props.maritalStatus_update(this.state.personal.maritalStatus)
    this.props.personal_update(this.state.personal)
    this.props.onGetData()
  }

    render(){

        return(
            <div>
                <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Full Name</b></h4>
                             <span className="text-danger">*</span>
                              <input className="form-control input-lg"
                                placeholder="Full Name" type="text" name="fullName"
                                  data-smart-validate-input="" data-required="" data-minlength="4"
                                   data-message="Please specify your Full name"
                                onChange={this.onChangePersonal.bind(this)}
                              />
                        </div>
                      </div>
                    </div>
                 </div>  
                 <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Mobile Phone</b></h4>
                               <span className="text-danger">*</span>
                               <NumberFormat className="form-control input-lg" data-minLength="10"
                                data-required="" placeholder="Phone Number of Loan Applicant"
                                 format=" #### #### #### ####" mask="_" name="mobile"  data-maxLength="16"
                                  onChange={this.onChangePersonal.bind(this)} required />
                                {/* <input className="form-control input-lg"
                                      data-smart-masked-input="+99 (999) 999-9999"
                                      data-mask-placeholder="X" placeholder=" Phone Number of Loan Applicant"
                                       type="number" name="mobile"
                                       data-smart-validate-input="" data-required=""
                                       data-minlength="10" mask="_"
                                       onChange={this.onChangePersonal.bind(this)}
                                /> */}
                        </div>
                        <br />
                        <div className="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                        <button
                          type="button"
                          className="btn btn-info btn-sm"
                          onClick={this.toggleInfo.bind(this, "phoneInfo")}
                        >
                          Add more phone numbers
                        </button>
                      </div>
                      </div>
                    </div>
                 </div>  
                 <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group"   id="phoneInfo"
                        style={{ display: this.state.phoneInfo ? "block" : "none" }}>
                        <br/>
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Landline</b></h4>
                              <NumberFormat className="form-control input-lg" data-minlength="4"
                                 placeholder="Landline of Loan Applicant"
                                 format="#### #### ####"  name="landlinePhone"  data-minlength="10"
                                  onChange={this.onChangePersonal.bind(this)} />
                             
                        </div>
                      </div>
                    </div>
                 </div>
                 <br />
                 <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Place of Birth</b></h4>
                             <input className="form-control input-lg"
                                        placeholder="Place of Birth" type="text" 
                                        name="placeOfBirth"
                                         data-smart-validate-input="" data-required="" data-minlength="4" data-maxLength="255"
                                         data-message="Please specify your place of birth"
                                         onChange={this.onChangePersonal.bind(this)}
                              />
                        </div>
                      </div>
                    </div>
                 </div>   
                 <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                            <h4  style={{float:"left"}}><b>Date of Birth</b></h4>
                                 <i className="icon-append fa fa-calendar"/>
                                  <input type="date" className="form-control" 
                                        id="datepicker" placeholder= "dd/mm/yyyy"
                                        name="dateOfBirth"
                                        data-smart-validate-input="" data-required=""
                                        data-message="Please specify your date of birth"
                                        onChange={this.onDate.bind(this)}
                                  /> 
                                </div>
                                </div>
                                </div>
                            </div> 
                        <div className="row" >
                          <div className="col-sm-6">
                            <div className="form-group">
                              <h4  style={{float:"left"}}><b>Gender</b></h4>
                              <br/>
                              <div className="col-xs-4 col-lg-8">
                            
                                      <div className="inputGroup-sizing-default">
                                          <label className="radio state-error" name="gender">
                                            <input type="radio" name="gender" value ="M" onChange={this.onChangePersonal.bind(this)}/>
                                              Male</label>
                                              &nbsp;&nbsp;&nbsp;
                                            <label className="radio">
                                            <input type="radio" name="gender" value="F" onChange={this.onChangePersonal.bind(this)}/>
                                              Female</label>
                                              {/* &nbsp;&nbsp;&nbsp;&nbsp; */}
                                      </div>
                            </div>
                        </div>
                      </div>
                  </div>  
                  <br/> 
                  <div className="row" >
                 <div className="col-sm-6">
                              <div className="form-group">
                                  <h4  style={{float:"left"}}><b>ID Type</b></h4>
                                    <span className="text-danger">*</span>
                                  <br/>
                                  <div className="col-sm-4 col-md-4 col-lg-8">
                                    <div className="inputGroup-sizing-default">
                                        <label className="radio state-error" >
                                            <input type="radio" name="idType"  
                                              onChange={this.onChangePersonal.bind(this)} value="KTP"/>
                                              KTP</label>
                                              &nbsp;&nbsp;&nbsp;&nbsp;
                                              <label className="radio">
                                              <input type="radio" name="idType" 
                                               onChange={this.onChangePersonal.bind(this)} value="SIM"/>
                                              SIM</label>
                                              &nbsp;&nbsp;&nbsp;&nbsp;
                                              <label className="radio">
                                              <input type="radio" name="idType" 
                                               onChange={this.onChangePersonal.bind(this)} value="Passport"/>
                                              Passport</label> 
                                              &nbsp;&nbsp;&nbsp;&nbsp;
                                    </div>
                           </div>
                      </div>
                    </div>
                 </div>  
                 <br/>
                 <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4 style={{float:"left"}}><b>ID Number</b></h4>
                                <span className="text-danger">*</span>
                                 <input className="form-control input-lg"
                                            placeholder="ID Number" type="number"
                                            name="idNum" data-smart-validate-input="" min="0"
                                            data-required="" data-minlength="16" data-maxlength="16"
                                            data-message="Please specify your number ID"
                                            onChange={this.onChangePersonal.bind(this)}/>
                        </div>
                      </div>
                    </div>
                 </div>
                 <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                                <label><h4 style={{float:"left"}}><b>Education</b></h4></label>
                              <div className="inputGroup-sizing-default">
                              <select className="form-control input-lg " 
                                        data-smart-validate-input="" data-required=""
                                        data-message-required="Please specify your education"
                                        name="education" defaultValue={"0"}
                                        onChange={this.onChangePersonal.bind(this)}>
                                    <option value="0" disabled={true}>Select Education</option>                                                                
                                    <option>SD</option>
                                    <option>SMP</option>
                                    <option>SMA</option>
                                    <option>D3</option>
                                    <option>D4</option>
                                    <option>S1</option>
                                    <option>S2</option>
                                    <option>S3</option>
                                    </select> 
                               {/* <div className="form-control input-lg"> */}
                                {/* <input className="col-xs-4 col-md-12 input-lg" required
                                name="education"
                                placeholder="Select a education..." type="text" list="list"
                                onChange={this.onChangePersonal.bind(this)}
                                />
                                <datalist id="list">
                                  <option value="SD">SD</option>
                                  <option value="SMP">SMP</option>
                                  <option value="SMA">SMA</option>
                                  <option value="D3">D3</option>
                                  <option value="D4">D4</option>
                                  <option value="S1">S1</option>
                                  <option value="S2">S2</option>
                                  <option value="S3">S3</option>
                              </datalist> */}
                            
                                </div>
                            </div>
                        </div>
                      </div>  
                  <br/> 
                 <div className="row" >
                         <div className="col-sm-6">
                          <div className="form-group">
                             <h4  style={{float:"left"}}><b>Marital Status</b></h4>
                             <br/>
                             <div className="col-xs-4 col-lg-8">
                                    <div className="inputGroup-sizing-default">
                                        <label className="radio state-error">
                                          <input type="radio" name="maritalStatus"  onChange={this.onMaritalStatus.bind(this)} value="Single"/>
                                            Single</label>
                                            &nbsp;&nbsp;&nbsp;
                                          <label className="radio">
                                          <input type="radio" name="maritalStatus"  onChange={this.onMaritalStatus.bind(this)} value="Married"/>
                                            Married</label>
                                            &nbsp;&nbsp;&nbsp;
                                            <label className="radio">
                                          <input type="radio" name="maritalStatus" onChange={this.onMaritalStatus.bind(this)} value="Divorced"/>
                                            Divorced</label>
                                            &nbsp;&nbsp;&nbsp;
                                            <label className="radio">
                                          <input type="radio" name="maritalStatus"  onChange={this.onMaritalStatus.bind(this)} value="Widow"/>
                                            Widow</label>
                                    </div>
                           </div>
                      </div>
                    </div>
                 </div>  
                 <br/> 
                 <div className="row">
                      <div className="col-sm-6">
                          <div className="form-group">
                          <div className="inputGroup-sizing-default">
                                    <h4  style={{float:"left"}}><b>Email</b></h4>
                              
                                    <input className="form-control input-lg"
                                         placeholder="email@address.com" type="text"
                                         name="email" data-smart-validate-input=""
                                         data-required="" data-email=""
                                         data-message-required="We need your email address to contact you"
                                         data-message-email="Your email address must be in the format of name@domain.com"
                                         onChange={this.onChangePersonal.bind(this)}     
                                    />
                              </div>
                          </div>
                      </div>
                  </div>

            </div>  
        )
        
    }
}