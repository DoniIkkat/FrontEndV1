import React from 'react'
// import province from '../../../../../components/forms/commons/province'

import SelectAddress from './SelectAddress';
import SelectUntil from '../SelectUntil';
import TypeCity from '../Type/TypeCity';

export default class Address extends React.Component{ 
    constructor(){
        super()
        this.state = {
            valueAdditional: false,
            valueUntil: false,
            // addressList: this.props.address_state
            address: {
                mainAddress: true
            },
            addressAdd:{
                mainAddress: false
            },
            addressList: [],
        }
    }

    componentDidMount(){
        // console.log(this.state.addressList)
        // console.log(this.props.address_state)
    }

    onAddAdditionalAddress(){
        this.setState({
            valueAdditional: !this.state.valueAdditional
        }, console.log(this.state.valueAdditional));
    }

    onChangeUntil(e){
        console.log(e.target.value)
        if(e.target.value==1){
            this.setState(prevState =>({
                valueUntil: true,
                address: {
                    ...prevState.address,
                    collateralUse: true
                }
            })) 
        }
        else {
            this.setState(prevState =>({
                valueUntil: false,
                address: {
                    ...prevState.address,
                    collateralUse: false
                }
            }))
        } 
    }
    
    onChangeAddress(e){
        const value = e.target.value;
        const addressData = e.target.name; 
        this.setState(prevState =>({
            address: {
                ...prevState.address,
                [addressData]: value
            },
            
        }),
        () => {
            this.setState({
                addressList: [this.state.address]
            },
            this.onReturnAddress.bind(this));
        }, 
        
        console.log(this.state.address),
        console.log("This is whats being returned", this.state.addressList),
        )
    }

    onChangeAddressAdditional(e){
        const value = e.target.value;
        const addressData = e.target.name;
        this.setState(prevState =>({
            addressAdd: {
                ...prevState.addressAdd,
                [addressData]: value
            }, 
        }),
        () => {
            this.setState({
                addressList: [this.state.address, this.state.addressAdd]
            },
            this.onReturnAddress.bind(this));
        }, 
        console.log("This is whats being returned", this.state.addressList)
        )
    }
    OnChangeProvince(e){
        const value = e.target.value;
        const addressData = e.target.name;
        this.setState(prevState =>({
            valueProv: value,
            address: {
                ...prevState.address,
                [addressData]: value
            },
            
        }),
        () => {
            this.setState({
                addressList: [this.state.address]
            },
            this.onReturnAddress.bind(this));
        }, 
        ) 
      }

    // OnChangeProvince(event){
    //     this.setState({
    //         valueProv: event.target.value,
    //         parameters: {}
    //     });
    // }

    onReturnAddress(){
        this.props.address_update(this.state.addressList);
        this.props.onGetData();
    }

    render(){
        let  maxOffset = 25;
        let thisYear = (new Date()).getFullYear();
        let allYears = [];
        for(let x = 0; x <= maxOffset; x++) {
            allYears.push(thisYear - x)
        }
    
        const yearList = allYears.map((x) => {return(<option value={x} key={x}>{x}</option>)});
        return(
            <div>
             <div className="row">
                <div className="col-sm-6">
                    <div className="form-group">
                    <div className="inputGroup-sizing-default">
                                <h4 style={{float:"left"}}><b>Main Address</b></h4>
                                <textarea rows="5" placeholder="Full Address" 
                                 className="form-control input-md" required  data-message="Please specify your address"
                                name="currentAddress"
                                onChange={this.onChangeAddress.bind(this)}
                                id="example-textarea" data-minlength="10" data-maxLength="255">
                                </textarea>
                          
                        </div>
                    </div>
                </div>
            </div>
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                               <h4 style={{float:"left"}}><b>Province</b></h4>
                               <input className="col-xs-4 col-md-12 input-lg" required
                                    onChange={this.OnChangeProvince.bind(this)} value={this.state.valueProv} 
                                    placeholder="Select a the province..." type="text" autoComplete="off"
                                    name="province" list="list2frst"
                                />
                                <datalist id="list2frst">
                                  <option value="DKI Jakarta">DKI Jakarta</option>
                                  <option value="Banten">Banten</option>
                                  <option value="Yogyakarta">Yogyakarta</option>
                                  <option value="Aceh">Aceh</option>
                                  <option value="Bali">Bali</option>
                                  <option value="Jawa Tengah">Jawa Tengah</option>
                                  <option value="Jawa Timur">Jawa Timur</option>
                                  <option value="Jawa Barat">Jawa Barat</option>
                                  <option value="Maluku">Maluku</option>
                                  <option value="Papua">Papua</option>
                              </datalist> 
                           
                            </div>
                        </div>
                      </div>
                    </div>  
                    <br/>
                    <TypeCity  
                        DivState={this.state.valueProv}
                        onChangeAddress= {this.onChangeAddress.bind(this)}
                    />
                    <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Postal Code</b></h4>
                                 <input className="form-control input-lg"
                                        placeholder="Postal Code" type="number"
                                        name="postalCode" 
                                        onChange={this.onChangeAddress.bind(this)}
                                        data-smart-validate-input="" maxLength="5"
                                        data-required=""data-minlength="5"/>
                                    </div>
                                </div>
                                </div>
                            </div>   
                            <div className="row" >
                                <div className="col-sm-6">
                                    <div className="form-group">
                                         <div className="inputGroup-sizing-default">                    
                                                    <h4 ><b>Ownership Status</b></h4>
                                                <select className="form-control input-lg"
                                                    data-smart-validate-input="" data-required=""
                                                    name="ownershipStatus" defaultValue={"0"}
                                                    onChange={this.onChangeAddress.bind(this)}
                                                    >
                                                <option value="0" disabled={true}>Choose</option>                                                                
                                                <option value="OWN">Own</option>
                                                <option value="FAMILY_HOUSE">Family Owned</option>
                                                <option value="RENT_ANNUALLY">Rent Annually</option>
                                                <option value="RENT_MONTHLY">Rent Monthly</option>
                                                </select> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div className="row" >
                                    <div className="col-sm-6">
                                    <div className="form-group">
                                        <h4  style={{float:"left"}}><b>Has been used for collateral elsewhere</b></h4>
                                        <br/>
                                        <div className="col-xs-4 col-lg-8">
                                    
                                                <div className="inputGroup-sizing-default">
                                                    <label className="radio state-error">
                                                    <input type="radio" name="collateralUse"
                                                        onChange={this.onChangeUntil.bind(this)}
                                                        value="1"/>
                                                        Yes</label>
                                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <label className="radio">
                                                    <input type="radio" name="collateralUse"
                                                        onChange={this.onChangeUntil.bind(this)} 
                                                        value="0"/>
                                                        No</label>
                                                </div>
                                         </div>
                                     </div>
                                </div>
                             
                            </div> 
                                <SelectUntil 
                                    DivState={this.state.valueUntil}
                                    onChangeAddress = {this.onChangeAddress.bind(this)}
                                />
                                <br/>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="form-group">
                                            <div className="input-group">                          
                                                  <h4 ><b>Has lived in the address since year</b></h4>
                                                    <select className="form-control input-lg" required
                                                        data-smart-validate-input="" data-required=""
                                                        name="usedYearSince"
                                                        onChange={this.onChangeAddress.bind(this)} 
                                                        defaultValue="0"
                                                        >
                                                        <option value="0" disabled={true}>Select Year</option> 
                                                        {yearList}
                                                    </select>    
                                            </div>
                                        </div>
                                    </div>
                                </div>
                <button id="js-checkbox-toggle" data-toggle="button" 
                className="btn  btn-md btn-primary mb-g waves-effect waves-themed" 
                value={this.state.valueAdditional} 
                onClick={this.onAddAdditionalAddress.bind(this)}>
                +Additional Address</button>
                <br/>
                <SelectAddress 
                    DivState={this.state.valueAdditional}
                    onChangeAddressAdditional={this.onChangeAddressAdditional.bind(this)}
                />
                <br/>
            </div>
            
        )
        
    }
}