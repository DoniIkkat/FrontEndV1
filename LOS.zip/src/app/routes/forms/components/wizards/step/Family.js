import React from 'react'
import ChildrenDiv from './family/numberOfChildrenDiv'
import Spouse from './family/Spouse'
import NumberFormat from 'react-number-format'

export default class Family extends React.Component{ 
    constructor(props){
        super(props);
        this.state = {
          family: {},
          emergencyAddress:{},

        }
      }
      changeHandler = e => {
		this.setState({ [e.target.name]: e.target.value })
    }

    onDateOfBirth(e){ 
        const value = `${e.target.value}T00:00:00.000+07:00`
        console.log(value);
        const DOBInput = e.target.name;
        this.setState(prevState =>({
          family: {
              ...prevState.family,
              [DOBInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
      }
    
    onChangeFamily(e){ 
        const value = e.target.value;
        const familyInput = e.target.name;
            console.log(this.state)
        this.setState(prevState =>({
          family: {
              ...prevState.family,
              [familyInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
    }
    
    onChangeSpouse(e){ 
        const value = e.target.value;
        const familyInput = e.target.name;
            console.log(this.state)
        this.setState(prevState =>({
          family: {
              ...prevState.family,
              spouseIdType: "KTP",
              [familyInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
    }

    onEmergencyAddress(e){
        const value = e.target.value;
        const emergencyData = e.target.name;
        this.setState(prevState =>({
          family: {
              ...prevState.family,
              emergencyAddress: {
                  [emergencyData]: value
              }
            }
        }),
        this.onReturnData.bind(this)
        
        )
    }

    onReturnData(){
        this.props.family_update(this.state.family);
        this.props.onGetData();
    }

    render(){
        let numberOfChildren = "";
        let spouse = "";
        if(this.props.marital_status == "Divorced" || this.props.marital_status == "Widow"){
            numberOfChildren = 
                <ChildrenDiv 
                    onChangeFamily = {this.onChangeFamily.bind(this)}
                />
            // console.log("DIVORCED / WIDOW")
        } else if(this.props.marital_status == "Married"){
            spouse = 
                <Spouse 
                    onChangeFamily = {this.onChangeSpouse.bind(this)}
                    onDateOfBirth = {this.onDateOfBirth.bind(this)}
                />;
            numberOfChildren = 
                <ChildrenDiv 
                    onChangeFamily = {this.onChangeFamily.bind(this)}
                />
            // console.log("Married")
        }

        return(
            <div>
                {spouse}
                {numberOfChildren} 
                    <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                            <h4  style={{float:"left"}}><b>Emergency Contact</b></h4>
                                <input className="form-control input-lg" 
                                    onChange={this.onChangeFamily.bind(this)}
                                    name="emergencyContactPersonName"
                                    placeholder="Name Emergency Contact" type="text" 
                                    data-smart-validate-input="" data-required="" data-minlength="4" 
                                    data-message="Please specify Emergency Contact"/>
                                </div>
                            </div>
                            </div>
                        </div> 
                        <div className="row" >
                        <div className="col-sm-6">
                            <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4  style={{float:"left"}}><b>Address Emergency Contact</b></h4>
                                    <textarea rows="5" placeholder="Full Address"   
                                    onChange={this.onEmergencyAddress.bind(this)}
                                    name="currentAddress"
                                    className="form-control input-md" required  data-message="Please specify your address emergency"
                                    id="example-textarea" data-minlength="10" data-maxLength="255">
                                    </textarea>
                                    {/* <input className="form-control input-lg" onChange={this.onChangeFamily.bind(this)}
                                        placeholder="Address Emergency Contact" type="text" name="Address Emergency Contact"
                                        data-smart-validate-input="" data-required="" data-minlength="4" 
                                        data-message="Please specify Address Emergency Contact"/> */}
                                    </div>
                                </div>
                                </div>
                            </div> 
                            <div className="row" >
                            <div className="col-sm-6">
                                <div className="form-group">
                                <div className="inputGroup-sizing-default">
                                    <h4  style={{float:"left"}}><b>Mobile Phone Emergency Contact</b></h4>
                                        {/* <input className="form-control input-lg"
                                                data-smart-masked-input="+62 (999) 999-9999"
                                                data-mask-placeholder="X" 
                                                onChange={this.onChangeFamily.bind(this)}
                                                name="emergencyContactMobile"
                                                placeholder="Phone Number of Emergency Contact"
                                                type="number" name="emergencyContactMobile"
                                                data-smart-validate-input="" data-required=""
                                                data-minlength="10"/> */}
                                        <NumberFormat className="form-control input-lg" data-minlength="4"
                                        data-required="" placeholder="Phone Number of Emergency Contact"
                                        format="### ### ####" mask="_" name="emergencyContactMobile"  data-minlength="10"
                                        onChange={this.onChangeFamily.bind(this)} required />
                                        </div>
                                      </div>
                                  </div>
                             </div> 
                                                  
            </div>
            
        )
        
    }
}