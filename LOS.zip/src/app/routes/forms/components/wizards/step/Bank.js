import React from 'react'
import CreditCard from './CreditCard'
import NumberFormat from 'react-number-format';


export default class Bank extends React.Component{ 
    constructor(props){
        super(props)
        this.state = {
            valueCC: false,
            // account: this.props.bankAccountstate,
            account: {
                bankId: 1
            }, 
            creditCardList: []
        }
    } 

    onChangeCreditCard(e){
        console.log("Bank",e.target.value)
        if(e.target.value==1)
            this.setState({
                valueCC: true
            });
        else {
            this.setState({
                valueCC: false
            });
        }
    }

    onCreditCard(param){
        
        this.setState(prevState =>({ 
            creditCardList: [param]
        }),
        this.onReturnCC.bind(this),
        // console.log("This is whats being returned", this.state.account)
        )
    }

    onReturnCC(){
        // console.log("CreditCarDlist",this.state.creditCardList),
        this.props.bank_creditCardUpdate(this.state.creditCardList) 
    }

    onChangeBank(e){
        const value = e.target.value;
        const bankData = e.target.name;
        this.setState(prevState =>({
            account: {
                ...prevState.account,
                [bankData]: value
            }
        }),
        this.onReturnBank.bind(this),
        // console.log("This is whats being returned", this.state.account)
        )
    }

    onReturnBank(){
        this.props.bank_update(this.state.account);
        this.props.onGetData();
    }

    render(){
        return(
            <div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Bank</b></h4>
                            <input className="col-xs-4 col-md-12 input-lg" required
                                name="nameOfBank"
                                onChange={this.onChangeBank.bind(this)}
                                placeholder="List of Banks" type="text" list="listBank"/>
                                <datalist id="listBank">
                                        <option value="Bank BCA">Bank BCA</option>
                                        <option value="Bank Mandiri">Bank Mandiri</option>
                                        <option value="Bank Danamon">Bank Danamon</option>
                                        <option value="Bank BRI">Bank BRI</option> 
                                        <option value="Bank BNI">Bank BNI</option> 
                                        <option value="Bank OCBC">Bank OCBC</option> 
                                        <option value="Bank Sinarmas">Bank Sinarmas</option> 
                                        <option value="Bank Mayapada">Bank Mayapada</option> 
                                        <option value="Bank Citibank">Bank Citibank</option> 
                                        <option value="Bank Mega">Bank Mega</option> 
                                        <option value="Bank HSBC">Bank HSBC</option> 
                                        <option value="Bank CimbNiaga">Bank CimbNiaga</option> 
                                        <option value="Bank Permata">Bank Permata</option> 
                                        <option value="Bank BII (MayBank)">Bank BII (MayBank)</option> 
                                  </datalist>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Account Type</b></h4>
                                <select className="form-control input-lg"
                                    data-smart-validate-input="" data-required=""
                                    name="accountType" 
                                    onChange={this.onChangeBank.bind(this)}
                                    defaultValue={"0"}>
                                    <option value="0" disabled={true}>Choose</option>                                                                
                                    <option>Current	Account</option>
                                    <option>Deposit</option>
                                    <option>Saving</option>
                                    </select> 
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Account Number</b></h4>
                            <NumberFormat className="form-control input-lg" minLength="10" 
                                   data-required="" placeholder="Enter your account Number" 
                                    format="#### #### #### ####"  onChange={this.onChangeBank.bind(this)}
                                    name="accountNumber" required/>
                              {/* <input className="form-control input-lg"
                                placeholder="Account Number" type="number"
                                name="accountNumber" minLength
                                onChange={this.onChangeBank.bind(this)}
                                data-smart-validate-input=""
                                data-required=""data-minlength="10" /> */}
                            </div>
                        </div>
                    </div>
                </div> 
                <div className="row" >
                          <div className="col-sm-6">
                            <div className="form-group">
                              <h4  style={{float:"left"}}><b>Credit Card</b></h4>
                              <br/>
                              <div className="col-xs-4 col-lg-8">
                              <div className="inputGroup-sizing-default">
                                                    <label className="radio state-error">
                                                    <input type="radio" name="ExampleRadio"
                                                        onChange={this.onChangeCreditCard.bind(this)}
                                                        value="1"/>
                                                        Yes</label>
                                                    <label className="radio">
                                                    <input type="radio" name="ExampleRadio"
                                                        onChange={this.onChangeCreditCard.bind(this)} 
                                                        value="0"/>
                                                        No</label>
                                   
                                      </div>
                            </div>
                        </div>
                      </div>
                  </div>  
                  <br/> 
                  <CreditCard 
                    divState={this.state.valueCC}
                    onCreditCard={this.onCreditCard.bind(this)}
                  /> 
            </div>
            
        )
        
    }
}