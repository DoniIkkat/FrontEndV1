import React from 'react'
import issuer from '../../../../../components/forms/commons/issuer';

export default class CreditCard extends React.Component{

    constructor(){
        super()
        this.state = {
            creditCard: {}
        }
    }

    onChangeCreditCard(e){
        const value = e.target.value;
        const CCData = e.target.name;
        this.setState(prevState => ({
            creditCard: {
                ...prevState.creditCard,
                [CCData]: value
            }
        }),
        () => {
            this.props.onCreditCard(this.state.creditCard)
        }
        )
    }

    render(){
        if(this.props.divState === true){
            return(
                <div>
                    <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Issuer</b></h4>
                                <input className="col-xs-4 col-md-12 input-lg" required 
                                    placeholder="Select a the issuer bank..." type="text" 
                                    autoComplete="off"
                                    name="issuer" 
                                    onChange={this.onChangeCreditCard.bind(this)}
                                    list="listIssuer"/>
                                    <datalist id="listIssuer">
                                    {issuer.map(function(issuer){
                                            return <option value={issuer.key} key={issuer.key}>{issuer.value}</option>
                                        })}
                                </datalist>
                            </div>
                        </div>
                    </div>
                </div> 
                <br/>
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                                  <h4 className="input" style={{float:"left"}}><b>Type Credit</b></h4>
                                    <select className="form-control input-lg"
                                                     data-smart-validate-input="" data-required=""
                                                     name="type" 
                                                     onChange={this.onChangeCreditCard.bind(this)}
                                                     defaultValue={"0"}>
                                                         <option value="0" disabled={true}>Type Credit</option>                                                                
                                                                <option>Platinum</option>
                                                                <option>Gold</option>
                                                                <option>Silver</option>
                                                                <option>Black</option>
                                        
                                    </select> 
                            </div>
                        </div>
                    </div>
                </div> 
                </div>
            );
        } else { 
            return <div></div>
        }  
    }
}