import React from 'react'
import Address2 from '../../wizards/step/Address2'

export default class SelectAddress extends React.Component{ 
    render(){ 

         if(this.props.DivState === true){ 
            return(
                <div>
                    <Address2 
                        onChangeAddressAdditional = {this.props.onChangeAddressAdditional.bind(this)}
                    />
                </div>                
            );
        }  else { 
            return <div></div>
        } 

        
    }
}