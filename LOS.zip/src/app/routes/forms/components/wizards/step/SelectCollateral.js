import React from 'react'
import Collateral from '../Collateral';

export default class SelectCollateral extends React.Component{ 
    constructor(props){
        super(props);
        this.state = { 
            // collateralId:"",
            valueC:""
        }
      }

    OnChangeCollateral(event){
        this.setState({
            valueC: event.target.value
        });
    }
    render(){
      
        return(
            <div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Collateral Type</b></h4>
                            <input className="col-xs-4 col-md-12 input-lg" 
                                 required data-message-required="Please Choose option" name="collateral" 
                                 onChange={this.OnChangeCollateral.bind(this)} value={this.state.valueC} 
                                placeholder="Choose Collateral..." type="text" list="listC"/>
                                    <datalist id="listC">
                                    <b>
                                    <option value="Real Estate">Real Estate</option>
                                    <option value="Vehicle">Vehicle</option>
                                    <option value="Deposit">Deposit</option> 
                                    </b>
                                </datalist>
                           
                            {/* <select className="form-control input-lg" onChange={this.changeHandler}
                                             data-smart-validate-input="" data-required=""
                                             onChange={this.OnChangeCollateral.bind(this)} value={this.state.valueC} 
                                             name="collateral"  defaultValue={"0"}>
                                                <option value="0" disabled={true}>Type Collateral</option>    
                                                <option value="1">Real Estate</option>
                                                <option value="2">Vehicle</option>
                                                <option value="3">Deposit</option> 
                                     </select>  */}
                            </div>
                        </div>
                    </div>
                </div>
                <Collateral  
                    DivState={this.state.valueC}
                    collateralUpdate = {this.props.collateralUpdate.bind(this)}
                    onGetData = {this.props.onGetData.bind(this)}
                />
            </div>
            
        )
        
    }
}