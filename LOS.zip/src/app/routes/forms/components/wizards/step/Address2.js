import React from 'react'
// import province from '../../../../../components/forms/commons/province'
import SelectUntil from '../SelectUntil';

import district from '../../../../../components/forms/commons/district';
import TypeCity from '../Type/TypeCity';


export default class Address2 extends React.Component{ 

    constructor(){
        super()
        this.state = {     
            value:"0",  
            valueUntil2: false,
            valueProv:''
        }
    }
    onChangeUntil2(e){
        console.log(e.target.value)
        if(e.target.value==1)
            this.setState({
                valueUntil2: true
            });
        else {
            this.setState({
                valueUntil2: false
            });
        }
    }

    OnChangeProvince(event){
        this.setState({
            valueProv: event.target.value,
            parameters: {}
        });
    }
    
    render(){
        return(
            <div>
                <br/>
                <div className="row">
                <div className="col-sm-6">
                    <div className="form-group">
                    <div className="inputGroup-sizing-default">
                                <h4 style={{float:"left"}}><b>Additional Address</b></h4>
                                <textarea rows="5" placeholder="Full Address" 
                                name="currentAddress"
                                onChange={this.props.onChangeAddressAdditional.bind(this)}
                                 className="form-control input-md" required  data-message="Please specify your address"
                                id="example-textarea" data-minlength="10" data-maxLength="255">
                                </textarea>
                          
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                               <h4 style={{float:"left"}}><b>Province</b></h4>
                               <input className="col-xs-4 col-md-12 input-lg" required
                                    onChange={this.OnChangeProvince.bind(this)} value={this.state.valueProv} 
                                    placeholder="Select a the province..." type="text" autoComplete="off"
                                    name="province" list="list2frst"
                                />
                                <datalist id="list2frst">
                                  <option value="DKI Jakarta">DKI Jakarta</option>
                                  <option value="Banten">Banten</option>
                                  <option value="Yogyakarta">Yogyakarta</option>
                                  <option value="Aceh">Aceh</option>
                                  <option value="Bali">Bali</option>
                                  <option value="Jawa Tengah">Jawa Tengah</option>
                                  <option value="Jawa Timur">Jawa Timur</option>
                                  <option value="Jawa Barat">Jawa Barat</option>
                                  <option value="Maluku">Maluku</option>
                                  <option value="Papua">Papua</option>
                              </datalist> 
                           
                            </div>
                        </div>
                      </div>
                    </div>  
                    <br/>
                    <TypeCity 
                        DivState={this.state.valueProv}/>
                    <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4  style={{float:"left"}}><b>Postal Code</b></h4>
                                 <input className="form-control input-lg"
                                        placeholder="Postal Code" type="number"
                                        name="postalCode"
                                        onChange={this.props.onChangeAddressAdditional.bind(this)}
                                        data-smart-validate-input=""
                                        data-required=""data-minlength="3" data-minlength="5"/>
                                    </div>
                                </div>
                                </div>
                            </div>   
                            <div className="row" >
                                <div className="col-sm-6">
                                    <div className="form-group">
                                         <div className="inputGroup-sizing-default">                    
                                                    <h4 ><b>Ownership Status</b></h4>
                                                <select className="form-control input-lg"
                                                    data-smart-validate-input="" data-required=""
                                                    name="dropdown" defaultValue={"0"}>
                                                <option value="0" disabled={true}>Choose</option>                                                                
                                                <option>Own</option>
                                                <option>Family Owned</option>
                                                <option>Rent Annually</option>
                                                <option>Rent Monthly</option>
                                                </select> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div className="row" >
                                    <div className="col-sm-6">
                                    <div className="form-group">
                                        <h4  style={{float:"left"}}><b>Has been used for collateral elsewhere</b></h4>
                                        <br/>
                                        <div className="col-xs-4 col-lg-8">
                                    
                                                <div className="inputGroup-sizing-default">
                                                    <label className="radio state-error">
                                                    <input type="radio" name="radio1s" defaultChecked
                                                        onChange={this.onChangeUntil2.bind(this)}
                                                        value="1"/>
                                                        Yes</label>
                                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <label className="radio">
                                                    <input type="radio" name="radio1s"
                                                        onChange={this.onChangeUntil2.bind(this)} 
                                                        value="0"/>
                                                        No</label>
                                                </div>
                                         </div>
                                     </div>
                                </div>
                             
                            </div> 
                                 <SelectUntil 
                                    DivState={this.state.valueUntil2}
                                    onChangeAddress = {this.props.onChangeAddressAdditional.bind(this)}
                                />
                                <br/>
                   </div>
        )
        
    }
}