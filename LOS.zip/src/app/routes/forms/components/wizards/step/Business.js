import React from 'react'
import division from '../../../../../components/forms/commons/division'
import TypeCity2 from './BussinesProv/TypeCity2';

export default class Business extends React.Component{ 
    constructor(){
        super()
        this.state = {       
            value: "0",
            companyAddress: {},
            business: '',
            valueProv:''
        }
    }

    onParse(e){
        const parsedNumb = parseInt(e.target.value, 10);
        const name = e.target.name;
        this.OnChangeCompany(parsedNumb, name)
    }

    onGet(e){
        const value = e.target.value;
        const company = e.target.name;
        this.OnChangeCompany(value, company)
    }

    OnChangeCompany(value, name){
        
        this.setState(prevState => ({
            business: {
                ...prevState.business,
                [name]: value
            }
        }), 
        // console.log(this.state.business),
            this.onReturnCompany.bind(this)
        )
       
    }

    onReturnCompany(){
        this.props.business_update(this.state.business);
        this.props.onGetData();
        console.log(this.state.business)
    }

    onReturnCompanyAddress(){
        this.props.business_addressUpdate(this.state.companyAddress)
        console.log(this.state.companyAddress)
    }

    onChangeCompanyAddress(e){
        const value = e.target.value;
        const address = e.target.name;
        this.setState(prevState => ({
            companyAddress: {
                ...prevState.companyAddress,
                [address]: value
            }
        }), 
        // console.log(this.state.companyAddress)
            this.onReturnCompanyAddress.bind(this)
        )
    }
    Province(e){
        this.OnChangeProvinces(e)
        this.setState({
            valueProv: e.target.value
        })
    }

    OnChangeProvinces(e){
        const value = e.target.value;
        const address = e.target.name; 
        this.setState(prevState => ({
            companyAddress: {
                ...prevState.companyAddress,
                [address]: value,
                district: "district",
                postalCode: "15345"
            }
        }), 
        // console.log(this.state.companyAddress)
            this.onReturnCompanyAddress.bind(this)
        )
    }
    
    render(){

        return(
            <div>
                <div className="row" >
                 <div className="col-sm-6">
                    <div className="form-group">
                    <div className="inputGroup-sizing-default">
                        <h4  style={{float:"left"}}><b>Company</b></h4>
                         <input className="form-control input-lg"
                                placeholder="Name of Company" type="text" 
                                name="companyName"
                                autoComplete="off"
                                onChange={this.onGet.bind(this)}
                                data-smart-validate-input="" data-required=""
                                data-message="Please specify your Company"/>
                                </div>
                            </div>
                            </div>
                        </div> 
                        <div className="row" >
                          <div className="col-sm-6">
                            <div className="form-group">
                                <div className="inputGroup-sizing-default">
                                  <h4  style={{float:"left"}}><b>Address Company</b></h4>
                                        <textarea rows="5" placeholder="Full Address of Company" 
                                        className="form-control input-md" required  data-message="Please specify your address"
                                        id="example-textarea" data-minlength="10" data-maxLength="255"
                                        onChange={this.onChangeCompanyAddress.bind(this)}
                                        name="currentAddress"
                                        >
                                        </textarea>
                                        </div>
                                    </div>
                                    </div>
                                </div> 
                                <br/>
                    <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                               <h4 style={{float:"left"}}><b>Province</b></h4>
                               <input className="col-xs-4 col-md-12 input-lg" required
                                    onChange={this.Province.bind(this)} value={this.state.valueProv} 
                                    placeholder="Select a the province..." type="text" autoComplete="off"
                                    name="province" list="list2frst"
                                />
                                <datalist id="list2frst">
                                  <option value="DKI Jakarta">DKI Jakarta</option>
                                  <option value="Banten">Banten</option>
                                  <option value="Yogyakarta">Yogyakarta</option>
                                  <option value="Aceh">Aceh</option>
                                  <option value="Bali">Bali</option>
                                  <option value="Jawa Tengah">Jawa Tengah</option>
                                  <option value="Jawa Timur">Jawa Timur</option>
                                  <option value="Jawa Barat">Jawa Barat</option>
                                  <option value="Maluku">Maluku</option>
                                  <option value="Papua">Papua</option>
                              </datalist> 
                           
                            </div>
                        </div>
                      </div>
                    </div>  
                    <br/>
                    <TypeCity2
                        DivState={this.state.valueProv}
                        OnChangeProvinces={this.OnChangeProvinces.bind(this)}
                    />  
                                            <br/>
                                        <div className="row" >
                                        <div className="col-sm-6">
                                            <div className="form-group">
                                                <div className="inputGroup-sizing-default">
                                                <h4  style={{float:"left"}}><b>Division</b></h4>
                                                    <input className="col-xs-4 col-md-12 input-lg" required 
                                                                placeholder="Select a Name of Division..." type="text" 
                                                                name="division" 
                                                                autoComplete="off"
                                                                onChange={this.onGet.bind(this)}
                                                                list="division"/>
                                                                <datalist id="division">
                                                                {division.map(function(division){
                                                                    return <option value={division.key} key={division.key}>{division.value}</option>
                                                                })}
                                                        </datalist>
                                                        </div>
                                                    </div>
                                                 </div>
                                            </div>
                                            <br />
                                    <div className="row" >
                                        <div className="col-sm-6">
                                            <div className="form-group">
                                                <div className="inputGroup-sizing-default">
                                                <h4  style={{float:"left"}}><b>Position</b></h4>
                                                    <select className="form-control input-lg"
                                                        data-smart-validate-input="" data-required=""
                                                        name="position" defaultValue={"0"}
                                                        onChange={this.onGet.bind(this)}
                                                    >
                                                    <option value="0" disabled={true}>Choose Position</option>                                                                
                                                    <option value="SENIOR MANAGER">Senior Manager</option>
                                                    <option value="CLERICAL SUPPORT WORKERS">Clerical Support Workers</option>
                                                    <option value="LABORERS AND UNSKILLED WORKERS">Laborers and Unskilled Workers</option>
                                                    </select> 
                                               </div>
                                           </div>
                                        </div>
                                    </div>
                                    <br />
                                            <div className="row" >
                                            <div className="col-sm-6">
                                                <div className="form-group">
                                                    <div className="inputGroup-sizing-default">
                                                    <h4  style={{float:"left"}}><b>Duration</b><label>&nbsp;( Months )</label></h4>
                                                         <input className="form-control input-lg"
                                                                placeholder="Length of Service with this Company, in months"
                                                                type="number" 
                                                                onChange={this.onParse.bind(this)}
                                                                name="employmentkDuration" 
                                                                data-smart-validate-input=""
                                                                data-required="" data-duration="" min="0"
                                                                data-message-required="We need your duration"/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div className="row" >
                                                <div className="col-sm-6">
                                                    <div className="form-group">
                                                        <div className="inputGroup-sizing-default">
                                                        <h4  style={{float:"left"}}><b>Total Number of Employees</b></h4>
                                                            <input className="form-control input-lg"
                                                                       placeholder="Total number of employees" type="number"
                                                                       name="totalNoEmployees" 
                                                                       onChange={this.onParse.bind(this)}
                                                                       data-smart-validate-input=""
                                                                       data-required=""min="0" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div> 
                                                    <div className="row" >
                                                    <div className="col-sm-6">
                                                        <div className="form-group">
                                                            <div className="inputGroup-sizing-default">
                                                            <h4  style={{float:"left"}}><b>Business line or industry</b></h4>
                                                                    <select className="form-control input-lg"
                                                                            data-smart-validate-input="" data-required=""
                                                                            name="businessIndustry" 
                                                                            onChange={this.onGet.bind(this)}
                                                                            defaultValue={"0"} required> 
                                                                        <option required value="0" disabled={true}>Select Business</option>                                                                
                                                                        <option>Agriculture </option>
                                                                        <option>Construction</option>
                                                                        <option>Manufacturing </option>
                                                                        <option>Mining and Utilities</option>
                                                                        <option>Financial</option>
                                                                        <option>General Services</option>
                                                                        <option>Insurance and Business Services </option>
                                                            
                                                                    </select> 
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                      
                                         
            </div>
            
        )
        
    }
}