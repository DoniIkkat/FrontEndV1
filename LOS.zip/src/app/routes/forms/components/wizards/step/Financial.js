import React from 'react'
import NumberFormat from 'react-number-format';

export default class Financial extends React.Component{
    constructor(props){
        super(props);
        this.state = { 
          finance: [{}],
          monthlyExpense:{},
          monthlyIncome:{}, 
          incomeSource: '',
          incomeMain : 0,
          incomeSide : 0, 
          expenseMain: 0,
          expenseSide: 0, 
        }
      }

      componentDidMount(){
      }

      ///INCOME
      ///////////////

      onMainIncome(e){
        if(e.target.value !== 0) {
            var str = e.target.value
            str = str.replace(/,/g, "")
            this.setState({
                incomeMain: str
            },
            this.onChangeIncome.bind(this)
            )
        }else {
            this.setState({
                incomeMain: 0
            },
            this.onChangeIncome.bind(this)
            )
        } 
      }

      onSideIncome(e){
        var str = e.target.value
        console.log("str= ",str)
        str = str.replace(/,/g, "")
        if(e.target.value !== 0) {
            this.setState({
                incomeSide: str
            },
            this.onChangeIncome.bind(this)
            )
        }else {
            this.setState({
                incomeSide: 0
            },
            this.onChangeIncome.bind(this)
            )
        } 
      } 

      onChangeIncome(){
        this.setState(prevState =>({
          monthlyIncome: { 
              value: parseInt(this.state.incomeMain, 10) + parseInt(this.state.incomeSide, 10),
              currency: "IDR"
            }
        }),
        this.onSetData.bind(this)
        )
      }

      ///EXPENSE
      ///////////////

      onMainExpense(e){
        if(e.target.value !== 0) {
            var str = e.target.value
            str = str.replace(/,/g, "")
            this.setState({
                expenseMain: str
            },
            this.onChangeExpense.bind(this)
            )
        }else {
            this.setState({
                expenseMain: 0
            },
            this.onChangeExpense.bind(this)
            )
        } 
      }

      onSideExpense(e){
        var str = e.target.value
        console.log("str= ",str)
        str = str.replace(/,/g, "")
        if(e.target.value !== 0) {
            this.setState({
                expenseSide: str
            },
            this.onChangeExpense.bind(this)
            )
        }else {
            this.setState({
                expenseSide: 0
            },
            this.onChangeExpense.bind(this)
            )
        } 
      } 

      onChangeExpense(){
        this.setState(prevState =>({
          monthlyExpense: {
              ...prevState.monthlyExpense,
              value: parseInt(this.state.expenseMain, 10) + parseInt(this.state.expenseSide, 10),
              currency: "IDR"
            }
        }),
        this.onSetData.bind(this)
        )
      }
    
    ///SOURCE INCOME
    /////////////////
    onChangeSourceIncome = (e) => {  
        console.log(e.target.value)
        this.setState({
            incomeSource: e.target.value
        },
        this.onSetData.bind(this))
    } 

    onSetData(){
        let source = this.state.incomeSource
        let income = this.state.monthlyIncome
        let expense = this.state.monthlyExpense
        this.setState(prevState =>({
            finance: [{
                incomeSource: source,
                monthlyExpense: expense,
                monthlyIncome: income
                // ...this.state.finance,
                // ...this.state.monthlyIncome,
                // ...this.state.monthlyExpense
            }]
        }),
        this.onSendData.bind(this)
        // console.log(this.state.finance)
        )
    }

    onSendData(){
        this.props.financialUpdate(this.state.finance);
        this.props.onGetData()
    }

    render(){
      
        return(
            <div>
                <div className="row">
                            <div className="col-sm-6">
                                <div className="form-group">
                                <div className="inputGroup-sizing-default">
                                    <h4 className="input" style={{textAlign:"left"}}><b>Type Income</b></h4>
                                    <select className="form-control input-lg" 
                                        onChange={this.onChangeSourceIncome}
                                        defaultValue="0"
                                                     data-smart-validate-input="" data-required=""
                                                     name="incomeSource"
                                                     >
                                                        <option value="0" disabled={true}>Type Income</option>    
                                                        <option>Employed </option>
                                                        <option>Self Employed</option>
                                                        <option>Disability </option>
                                                        <option>Retirement/Pension</option>
                                                        <option>Part-Time</option>
                                                        <option>Unemployment </option>
                                                    
                                             </select> 
                                    </div>
                                </div>
                            </div>
                        </div>
                         <div className="row">
                                        <div className="col-sm-6">
                                            <div className="form-group">
                                                <div className="inputGroup-sizing-default">
                                                <h4 className="input" style={{textAlign:"left"}}><b>Main Income</b> ( IDR )</h4>
                                                    <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                                                        thousandSeparator={true} placeholder="Input your income" 
                                                        onChange={this.onMainIncome.bind(this)} 
                                                        name="value" required data-message="Please specify your income"
                                                        />
                                                    
                                                    {/* <input className="form-control input-lg" id="exampleNumber" min="0"
                                                            placeholder="Input your income" type="number" 
                                                            name="value"
                                                            data-smart-validate-input="" data-required=""
                                                            onChange={this.onMainIncome.bind(this)}
                                                            data-message="Please specify your income"/> */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="form-group">
                                                        <div className="inputGroup-sizing-default">
                                                            <h4 className="input" style={{textAlign:"left"}}><b>Side Income</b> ( IDR )</h4>
                                                                <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                                                                    thousandSeparator={true} placeholder="Input your income" 
                                                                    onChange={this.onSideIncome.bind(this)}
                                                                    name="value" required data-message="Please specify your side income"
                                                                    />
                                                                
                                                                {/* <input className="form-control input-lg"
                                                                       min="0"
                                                                       placeholder="Input your income" type="number" 
                                                                       name="value"
                                                                       
                                                                       onChange={this.onSideIncome.bind(this)}
                                                                       data-smart-validate-input="" data-required=""
                                                                       data-message="Please specify your side income"/> */}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="form-group">
                                                            <div className="inputGroup-sizing-default">
                                                            <h4 className="input-number" style={{textAlign:"left"}}><b>Expense</b> ( IDR )</h4>
                                                                <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                                                                        thousandSeparator={true} placeholder="Input your expense" 
                                                                        onChange={this.onMainExpense.bind(this)}
                                                                        name="value" required data-message="Please specify your expense"
                                                                        />
                                                                
                                                                {/* <input className="form-control input-lg" id="exampleNumber"min="0"
                                                                       placeholder="Input your expense" type="number" 
                                                                       name="value"
                                                                       onChange={this.onMainExpense.bind(this)}
                                                                       data-smart-validate-input="" data-required="We need your number expense"
                                                                       data-message="Please specify your expense"/> */}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="form-group">
                                                            <div className="inputGroup-sizing-default">
                                                            <h4 className="input-number" style={{textAlign:"left"}}><b>Additional Expense</b> ( IDR )</h4>
                                                                <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                                                                    thousandSeparator={true} placeholder="Input your expense" 
                                                                    onChange={this.onSideExpense.bind(this)}
                                                                    name="value" required data-message="Please specify your expense"
                                                                    />     
                                                                 <div className="note">
                                                                        <strong>Note:</strong> format text input in  IDR
                                                                    </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
            </div>
            
        )
        
    }
}