import React from 'react'
import NumberFormat from 'react-number-format';
import { parse } from 'querystring';

//npm install react-number-format --save
export default class Loan extends React.Component{ 
  constructor(props){
    super(props);
    this.state = {
      posts: [],
      loan: {}
    }
  }

  componentDidMount(){
      const url = `${this.props.baseUrl}/loan/products/v1/`;
      fetch(url,{
        method: "GET",
        headers: {
          'Authorization': 'Bearer ' +localStorage.getItem('token')
        },
        }).then(reponse => reponse.json())
        .then(posts => {
          JSON.stringify(posts) 
          this.setState({posts: posts})
        })
  }

    onReturnLoan(){
      this.props.loan_update(this.state.loan)
      this.props.onGetData()
      console.log(this.props.loan_console)
    }

    onParseAmount(e){
      var str = e.target.value
      str = str.replace(/,/g, "")
      var parsedNumb = parseInt(str)

      this.setState(prevState =>({
        loan: {
          ...prevState.loan,
          loanAmount:{
            value: parsedNumb,
            currency: "IDR"
          }
        }
      }),
      this.onReturnLoan.bind(this)
      )
    }
    
    onParseMonth(e){ 
      var str = e.target.value
      str = str.replace(/,/g, "")
      var parsedNumb = parseInt(str)
      const prodId = e.target.name;
      this.setState(prevState =>({
        loan: {
            ...prevState.loan,
            [prodId]: parsedNumb,
            tenorInMonths: parsedNumb
          }
      }),
      this.onReturnLoan.bind(this),
      )
    }

    onChangeLoanProduct(e){  
      const value = e.target.value;
      const prodId = e.target.name;
      this.setState(prevState =>({
        loan: {
            ...prevState.loan,
            [prodId]: value
          }
      }),
      this.onReturnLoan.bind(this),
      // console.log("This is whats being returned", this.state.loan.loanProductId, this.state.loan.loanAmount, this.state.loan.tenor, this.state.loan.purpose)
      ) 
    } 

    render(){
        return(
            <div>
                 <div className="row">
                    <div className="col-md-6 mar-btm">
                        <div className="form-group">
                        <br/>
                        <h4 style={{float:"left"}}><b>Loan Product</b></h4>
                       
                        <div className="inputGroup-sizing-default"> 

                                    <select className="form-control input-lg"
                                        data-smart-validate-input="" data-required=""
                                        name="loanProductId" defaultValue={"0"}
                                        onChange={this.onChangeLoanProduct.bind(this)} 
                                    >
                                     <option value="0" disabled={true}>Select product</option> 
                                     {this.state.posts.map(function(item){
                                         return(
                                            <option key={item.loanProductId} value={item.loanProductId}>{item.name}</option>
                                         )
                                     })}
                                    </select> 
                            </div>
                        </div>
                    </div>
                  </div>  
                 <div className="row" >
                    <div className="col-sm-6 mar-btm">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4 style={{float:"left"}}><b>Loan Amount</b><label>&nbsp;( IDR )</label></h4>
                            
                              <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                              thousandSeparator={true} placeholder="Enter your loan amount" 
                              onChange={this.onParseAmount.bind(this)} 
                              name="loanAmount" required
                              />
                            
                        </div>
                      </div>
                    </div>
                 </div>   
                 <div className="row" >
                    <div className="col-sm-6 mar-btm">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4 style={{float:"left"}}><b>Purpose of Loan</b></h4>
                                <select className="form-control input-lg " 
                                        data-smart-validate-input="" data-required=""
                                        data-message-required="Please specify your purpose"
                                        name="purpose" defaultValue={"0"}
                                        onChange={this.onChangeLoanProduct.bind(this)}  >
                                    <option value="0" disabled={true}>Select Purpose</option>                                                                
                                    <option>Education</option>
                                    <option>Consumer Purchase</option>
                                    <option>Debt Repayment</option>
                                    <option>Holiday</option>
                                    <option>Venture Capital</option>
                                    <option>Medical Bill</option>
                                    <option>Purchase Vehicle</option>
                                    <option>Wedding</option>
                                    </select> 
                                
                        </div>
                      </div>
                    </div>
                 </div>  
                 <div className="row" >
                    <div className="col-sm-6 mar-btm">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4 style={{float:"left"}}><b>Tenor</b><label>&nbsp;( Months )</label></h4>
                                <input className="form-control input-lg" min="0"
                                    placeholder="Length of Time until Loan is Due in Months" type="number" name="tenor"
                                    data-smart-validate-input="" data-required=""
                                    data-message="Please specify your tenor  (such as 12 months)"
                                    onChange={this.onParseMonth.bind(this)}
                                /> 
                        </div>
                      </div>
                    </div>
                 </div>                  
               </div>
            
        )
        
    }
}