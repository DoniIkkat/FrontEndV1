import React from 'react'
import DropzoneInput from '../../../../../components/forms/inputs/DropzoneInput'

export default class Document extends React.Component{ 
    constructor(){
        super()
        this.state = {       
            value: "0" 
        }
    }
    render(){
        return(
            <div>
                  <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                             <h4 style={{float:"left"}}><b>Description</b></h4>
                             <input className="form-control input-lg"
                                        placeholder="Type (Category, Intent or Training)" type="text" name="place_of_birth"
                                         data-smart-validate-input="" data-required="" data-minlength="4" data-maxLength="255"
                                         data-message="Please specify your Description"/>
                        </div>
                      </div>
                    </div>
                 </div>   
                                                
                 <div className="row">
                 <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                 <header>
                 
                  <h2>UPLOAD</h2>

                </header>


                  {/* widget content */}
                  <div className="widget-body">

                    <DropzoneInput options={{
                      addRemoveLinks: true,
                      maxFilesize: 0.5,
                      dictDefaultMessage: '<span class="text-center"><span class="font-lg visible-xs-block visible-sm-block visible-lg-block"><span class="font-lg"><i class="fa fa-caret-right text-danger"></i> Drop files <span class="font-xs">to upload</span></span><span>&nbsp&nbsp<h4 class="display-inline"> (Or Click)</h4></span>',
                      dictResponseError: 'Error uploading file!'
                    }}>
                      <form action="/upload" className="dropzone" id="file"/>
                    </DropzoneInput>
                    <span className="widget-icon"> <i className="fa fa-cloud-upload text-muted mb-3"/> </span>
                    </div>
                    
                 </div> 
                </div>                           
            </div>
            
        )
        
    }
}

// ReactDOM.render(
//   <Document /> ,
//   document.getElementById('container')
// );