import React from 'react'
import {WidgetGrid, JarvisWidget}  from '../../../../../components'
import Loan from './Loan';
import Personal from './Personal';
import Address from './Address';
import FamilySum from '../SummaryData/FamilySum';
import BusinessSum from '../SummaryData/BusinessSum';
import FinancialSum from '../SummaryData/FinancialSum';
import Bank from './Bank';

import SelectCollateral from './SelectCollateral';
import LoanSum from '../SummaryData/LoanSum';
import PersonalSum from '../SummaryData/PersonalSum';
import BankSum from '../SummaryData/BankSum';

export default class Summarys extends React.Component{

    onClickSubmit(){
        this.props.appPost()
        this.props.onSubmitData()
    }

    render(){  
        return(
            
            <div>
                 <WidgetGrid sortable={false}>
            
            <div className="row">
              <article className="col-md-8">
              <JarvisWidget colorbutton={false} editbutton={false}
                            custombutton={false}
                            color="blueDark">
                <header>
                    <span className="widget-icon"> </span>
                          <h2>Loan Application</h2>
                </header>
                <div>
                    <LoanSum 
                        loan ={this.props.all.loan}
                    />
                </div>
              </JarvisWidget>
              </article>
                <article className="col-md-8">
                <JarvisWidget colorbutton={false} editbutton={false}
                                custombutton={false}
                                color="blueDark">
                    <header>
                        <span className="widget-icon"> </span>
                            <h2>Personal Information</h2>

                    </header>
                    <div>
                        <PersonalSum 
                            personal = {this.props.all.personal}
                        />
                    </div>
                    </JarvisWidget>
                    </article>
                    <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Address</h2>

                        </header>
                        <div>
                            <Address 
                                
                            />
                        </div>
                 </JarvisWidget>
                 </article>
                 <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Family Information</h2>

                        </header>
                        <div>
                            <FamilySum
                                family= {this.props.all.family}
                                marital_status = {this.props.marital_status}
                            />
                        </div>
                 </JarvisWidget>
                 </article>
                 <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Business Information</h2>

                        </header>
                        <div>
                            <BusinessSum
                                business = {this.props.all.business}
                            />
                        </div>
                 </JarvisWidget>
                 </article>
                 <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Financial Information</h2>

                        </header>
                        <div>
                            <FinancialSum
                                finance = {this.props.all.finance}
                            />
                        </div>
                 </JarvisWidget>
                 </article>
                 <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Bank Information</h2>

                        </header>
                        <div>
                            <BankSum 
                                bank = {this.props.all.bank}
                                valueCC = {this.props.valueCC}
                            />
                        </div>
                 </JarvisWidget>
                 </article>
                 <article className="col-md-8">
                    <JarvisWidget colorbutton={false} editbutton={false}
                                    custombutton={false}
                                    color="blueDark">
                        <header>
                            <span className="widget-icon"> </span>
                                <h2>Collateral</h2>

                        </header>
                        <div>
                           {/* <SelectCollateral/> */}
                        </div>
                 </JarvisWidget>
                 </article>
                
                 <footer className="col-xs-5 col-sm-5 col-md-5 col-lg-5">
                        <a className="btn btn-primary"
                            onClick={this.onClickSubmit.bind(this)}
                        >
                          Submit
                        </a>
                    </footer>
                </div> 
              </WidgetGrid> 
             </div>
            
        )
        
    }
}