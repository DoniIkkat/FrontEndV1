import React from 'react'
import { updateRealEstate } from '../actions/collateralAction';

export default class LoanSum extends React.Component{

    render(){
        return(
            <div>
                 <div className="row">
                    <div className="col-md-6">
                      <h4 ><b>Loan Product</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.loan.loanProductId!=undefined ? this.props.loan.loanProductId : "Empty"}
                      </h4>
                    </div>
                  </div>  
                 <br />
                 <div className="row" >
                    <div className="col-sm-6">
                      <h4 ><b>Loan Amount</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4 style={{float:"center"}}>
                        {this.props.loan.loanAmount.value!=undefined || this.props.loanAmount.value!=0 ? this.props.loan.loanAmount.value: "Empty" }
                      </h4>
                    </div>
                 </div>   
                 <br />
                 <div className="row" >
                    <div className="col-sm-6">
                      <h4 ><b>Purpose of Loan</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.loan.purpose!=undefined ? this.props.loan.purpose : "Empty"}
                      </h4>
                    </div>
                 </div>  
                 <br />
                 <div className="row" >
                    <div className="col-sm-6">
                      <h4 ><b>Tenor<span className="text-danger col-xs">(Months)</span></b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4 style={{float:"center"}}>
                        {this.props.loan.tenor!=undefined ? this.props.loan.tenor : "Empty"}
                      </h4>
                    </div>
                 </div>            
                 <br />
               </div>
            
        )
        
    }
}