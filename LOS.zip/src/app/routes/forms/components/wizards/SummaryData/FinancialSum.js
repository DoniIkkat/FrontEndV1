import React from 'react'

export default class FinancialSum extends React.Component{
    render(){
        return(
            <div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4 className="input" style={{textAlign:"left"}}><b>Type Income</b></h4>
                                {/* {this.props.financial.incomeSource!=undefined ? this.props.financial.incomeSource : "Empty"} */}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Main Income</b></h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                        <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Side Income</b></h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input-number" style={{textAlign:"left"}}><b>Expense</b></h4>

                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input-number" style={{textAlign:"left"}}><b>Additional Expense</b></h4>
                                        <h5>
                                            
                                        </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        )
        
    }
}