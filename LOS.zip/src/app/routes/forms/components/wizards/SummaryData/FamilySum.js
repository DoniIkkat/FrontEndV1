import React from 'react'
import ChildrenDiv from '../step/family/numberOfChildrenDiv'
import Spouse from '../step/family/Spouse'

export default class Family extends React.Component{  
    constructor(){
        super()
        this.state={
            summary: true
        }
    }
    render(){
        // console.log("MARITAL STATS", this.props.marital_status)
        let numberOfChildren = "";
        let spouse = "";
        if(this.props.marital_status == "Divorced" || this.props.marital_status == "Widow"){
            numberOfChildren = 
                <ChildrenDiv 
                    summary = {this.state.summary}
                    family = {this.props.family}
                />
            // console.log("DIVORCED / WIDOW")
        } else if(this.props.marital_status == "Married"){
            spouse = 
                <Spouse 
                    summary = {this.state.summary}
                    family = {this.props.family}
                />;
            numberOfChildren = 
                <ChildrenDiv 
                    summary = {this.state.summary}
                    family = {this.props.family}
                />
            // console.log("Married")
        }

        return(
            <div>
                {spouse}
                {numberOfChildren} 
                <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4  style={{float:"left"}}><b>Emergency Contact</b></h4>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.family.emergencyContactPersonName!=undefined ? this.props.family.emergencyContactPersonName : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4  style={{float:"left"}}><b>Address Emergency Contact</b></h4>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.family.emergencyAddress.currentAddress!=undefined ? this.props.family.emergencyAddress.currentAddress : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                                <h4  style={{float:"left"}}><b>Mobile Phone Emergency Contact</b></h4> 
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.family.emergencyContactMobile!=undefined ? this.props.family.emergencyContactMobile : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br />                          
            </div>
            
        )
        
    }
}