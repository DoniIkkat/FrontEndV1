import React from 'react'
import NumberFormat from 'react-number-format';

export default class PersonalSum extends React.Component{  

    render(){
        return(
            <div>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Full Name</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.fullName!=undefined ? this.props.personal.fullName : "Empty"}
                      </h4>  
                    </div>
                 </div>  
                 <br/>
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Mobile Phone</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.mobile!=undefined ? this.props.personal.mobile : "Empty"}
                      </h4>
                    </div>
                 </div>  
                 <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Landline</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.landlinePhone!=undefined ? this.props.personal.landlinePhone : "Empty"}
                      </h4>
                    </div>
                 </div>  
                 <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Place of Birth</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.placeOfBirth!=undefined ? this.props.personal.placeOfBirth : "Empty"}
                      </h4> 
                    </div>
                 </div>   
                 <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Date of Birth</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.dateOfBirth!=undefined ? this.props.personal.dateOfBirth : "Empty"}
                      </h4> 
                    </div>
                  </div> 
                  <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Gender</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.gender!=undefined ? this.props.personal.gender : "Empty"}
                      </h4>
                    </div>
                  </div> 
                  <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>ID Type</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.idType!=undefined ? this.props.personal.idType : "Empty"}
                      </h4>
                    </div>
                 </div>
                 <br/>
                <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>ID Number</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.idNum!=undefined ? this.props.personal.idNum : "Empty"}
                      </h4>
                    </div>
                 </div>
                 <br/>
                <div className="row">
                    <div className="col-md-6">
                      <h4 style={{float:"left"}}><b>Education</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.education!=undefined ? this.props.personal.education : "Empty"}
                      </h4>
                    </div>
                  </div>  
                  <br/> 
                 <div className="row" >
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Marital Status</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.maritalstatus!=undefined ? this.props.personal.maritalstatus : "Empty"}
                      </h4>  
                    </div>
                 </div>  
                 <br/> 
                 <div className="row">
                    <div className="col-sm-6">
                      <h4  style={{float:"left"}}><b>Email</b></h4>
                    </div>
                    <div className="col-md-6">
                      <h4>
                        {this.props.personal.email!=undefined ? this.props.personal.email : "Empty"}
                      </h4>
                    </div>
                  </div>
                  <br/>
            </div>  
        )
        
    }
}