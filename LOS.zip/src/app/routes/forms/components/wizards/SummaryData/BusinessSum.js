import React from 'react' 

export default class Business extends React.Component{
    
    render(){ 
        return(
            <div>
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Company</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.companyName!=undefined ? this.props.business.companyName : "Empty"}
                        </h4>
                    </div>
                </div>
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Address Company</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.companyAddress.currentAddress!=undefined ? this.props.business.companyAddress.currentAddress : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br/>
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Province</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.companyAddress.province!=undefined ? this.props.business.companyAddress.province : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br/>
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>City</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.companyAddress.city!=undefined ? this.props.business.companyAddress.city : "Empty"}
                        </h4>
                    </div>
                </div>  
                <br/>
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Division</b></h4>
                     </div>
                     <div className="col-md-6">
                        <h4>
                            {this.props.business.division!=undefined ? this.props.business.division : "Empty"}
                        </h4>
                     </div>
                </div>
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Duration</b><label>&nbsp;( Months )</label></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.employmentkDuration!=undefined ? this.props.business.employmentkDuration : "Empty"}
                        </h4>
                    </div>
                </div>
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Total Number of Employees</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.totalNoEmployees!=undefined ? this.props.business.totalNoEmployees : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br />
                <div className="row" >
                    <div className="col-sm-6">
                        <h4  style={{float:"left"}}><b>Business line or industry</b></h4> 
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.business.businessIndustry!=undefined ? this.props.business.businessIndustry : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br />                   
                                         
            </div>
            
        )
        
    }
}