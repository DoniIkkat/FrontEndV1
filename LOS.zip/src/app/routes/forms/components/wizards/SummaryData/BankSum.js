import React from 'react'
import CreditCard from '../step/CreditCard'

var summary = true;

export default class BankSum extends React.Component{  
    
    render(){
        console.log(this.props.bank.creditCardList)
        if(this.props.valueCC == true){
            summary = true
        }
        else summary = false
        return(
            <div>
                <div className="row">
                    <div className="col-sm-6">
                        <h4 className="input" style={{textAlign:"left"}}><b>Bank</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.bank.account.nameOfBank!=undefined ? this.props.bank.account.nameOfBank : "Empty"}
                        </h4>
                    </div>
                </div>
                <br />
                <div className="row">
                    <div className="col-sm-6">
                        <h4 className="input" style={{textAlign:"left"}}><b>Account Type</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.bank.account.accountType!=undefined ? this.props.bank.account.accountType : "Empty"}
                        </h4>
                    </div>
                </div>
                <br />
                <div className="row">
                    <div className="col-sm-6">
                        <h4 className="input" style={{textAlign:"left"}}><b>Account Number</b></h4>
                    </div>
                    <div className="col-md-6">
                        <h4>
                            {this.props.bank.account.accountNumber!=undefined ? this.props.bank.account.accountNumber : "Empty"}
                        </h4>
                    </div>
                </div> 
                <br/>
                <CreditCard
                    creditCard = {this.props.bank.creditCardList}
                    summary = {summary}
                    divState = {false}
                />
            </div>
            
        )
        
    }
}