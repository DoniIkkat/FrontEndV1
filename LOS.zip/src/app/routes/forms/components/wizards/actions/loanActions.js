import {url} from '../../../../../config/baseUrl'

export const UPDATE_LOAN = 'UPDATE_LOAN'

export function postLoan(params){
    return dispatch => {
        fetch(`${url}/loan/application/v1/apply`, 
        {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer '+localStorage.getItem('token'),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        })
        // .then(dispatch(updateLoan(params)))
        .then(response => console.log('LOAN POSTED', response.status))
        // console.log('LOAN POSTED', params)
    }
}

export function postData(params){
    return dispatch => {
        fetch(`${url}/loan/application/v1/apply`, 
        {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer '+localStorage.getItem('token'),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        })
        // .then(dispatch(updateLoan(params)))
        .then(response => console.log('LOAN SUBMITTED', response.status))
        // console.log('LOAN POSTED', params)
    }
}

export function getApplicants(){
    return dispatch => {
        fetch(`${url}/loan/application/v1/applicant-list`, 
        {
            method: 'GET',
            headers: {
                Authorization: 'Bearer '+localStorage.getItem('token')
            }, 
        })
        .then(reponse => reponse.json())
        .then(appList => {
            console.log(appList)
        //   JSON.stringify(posts) 
        //   this.setState({posts: posts})
        })
    }
}

export function updateLoan(newLoan){
    return{
        type: UPDATE_LOAN,
        payload: newLoan
    }
} 