import React from 'react'
import DropzoneInput from '../../../../components/forms/inputs/DropzoneInput'
import NumberFormat from 'react-number-format';

export default class CollateralBank extends React.Component{ 
    state = {
        fileInputValue: '',
        collateralTypeId: 2,
        parameters: {}
      };

      onParse(e){ 
        var str = e.target.value
        str = str.replace(/,/g, "")
        var parsedNumb = parseInt(str)
        const prodId = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [prodId]: parsedNumb
            }
        }),
            this.onReturnData.bind(this)
        )
      }

      onDate(e){ 
        const value = `${e.target.value}T00:00:00.000+07:00` 
        const personalInput = e.target.name;
        this.setState(prevState =>({
          parameters: {
              ...prevState.parameters,
              [personalInput]: value
            }
        }),
        this.onReturnData.bind(this)
        )
      }

      onChangeDeposit(e){
        const value = e.target.value;
        const prodId = e.target.name;
        this.setState(prevState =>({
            parameters: {
                ...prevState.parameters,
                [prodId]: value
            }
        }),
            this.onReturnData.bind(this)
        ) 
      }

      onReturnData(){ 
          this.props.collateralList(this.state)
      }
    
      onSubmit(e) {
        e.preventDefault();
        console.log('submit stuff')
      }
    
      onFileInputChange = (e)=>{
        this.setState({
          fileInputValue: e.target.value
        })
      }

    render(){
        return(
            <div>
                <br/>
                 <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Bank</b></h4>
                                <input className="col-xs-4 col-md-12 input-lg"
                                    data-message-required="We need your input bank"
                                    name="bank" 
                                    onChange={this.onChangeDeposit.bind(this)}
                                    placeholder="List of Banks" type="text" list="listBanks"/>
                                    <datalist id="listBanks">
                                            <option value="Bank BCA">Bank BCA</option>
                                            <option value="Bank Mandiri">Bank Mandiri</option>
                                            <option value="Bank Danamon">Bank Danamon</option>
                                            <option value="Bank BRI">Bank BRI</option> 
                                            <option value="Bank BNI">Bank BNI</option> 
                                            <option value="Bank OCBC">Bank OCBC</option> 
                                            <option value="Bank Sinarmas">Bank Sinarmas</option> 
                                            <option value="Bank Mayapada">Bank Mayapada</option> 
                                            <option value="Bank Citibank">Bank Citibank</option> 
                                            <option value="Bank Mega">Bank Mega</option> 
                                            <option value="Bank HSBC">Bank HSBC</option> 
                                            <option value="Bank CimbNiaga">Bank CimbNiaga</option> 
                                            <option value="Bank Permata">Bank Permata</option> 
                                            <option value="Bank BII (MayBank)">Bank BII (MayBank)</option> 
                                            <option value="Shinhan Bank">Shinhan Bank</option> 
                                    </datalist> 
                            </div>
                        </div>
                    </div>
                </div>
                <br />
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Amount </b></h4>
                            <NumberFormat className="form-control input-lg" data-minlength="4" data-required=""
                              thousandSeparator={true} placeholder="Enter your loan amount" 
                              onChange={this.onParse.bind(this)} 
                              name="amount" required
                              />

                            {/* <input className="form-control input-lg" min="0"
                                placeholder="Amount of Deposit" type="number" name="amount"
                                data-smart-validate-input="" data-required=""
                                data-message="Please specify Amount of Deposit"/> */}

                            </div>
                        </div>
                    </div>
                </div>        
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Currency </b></h4>
                                <select className="form-control input-lg"
                                    data-smart-validate-input="" data-required=""
                                    name="currency"
                                    onChange={this.onChangeDeposit.bind(this)}
                                    defaultValue={"0"}>
                                    <option value="0" disabled={true}>List of Currencies</option>    
                                    <option>IDR</option>
                                    <option>USD</option>
                                    <option>SGD</option>  
                                </select>  
                            </div>
                        </div>
                    </div>
                </div>   
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Account Number </b></h4>
                            <NumberFormat className="form-control input-lg" minLength="10" 
                                   data-message="Please specify Amount of Deposit"
                                    placeholder="Enter your account Number" min="0"
                                    format="#### #### #### ####" onChange={this.onChangeDeposit.bind(this)}
                                    name="accno" required/>
                         
                            </div>
                        </div>
                    </div>
                </div>             
                <div className="row">
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="inputGroup-sizing-default">
                            <h4 className="input" style={{textAlign:"left"}}><b>Due date</b></h4>
                             <input type="date" className="form-control" id="datepicker"
                                name="duedate"
                                onChange={this.onDate.bind(this)}
                             />
                            </div>
                        </div>
                    </div>
                </div>  
                <div className="row">
                 <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                 <header>
                 
                  <h2>UPLOAD</h2>

                </header>


                  {/* widget content */}
                  <div className="widget-body">

                    <DropzoneInput options={{
                      addRemoveLinks: true,
                      maxFilesize: 0.5,
                      dictDefaultMessage: '<span class="text-center"><span class="font-lg visible-xs-block visible-sm-block visible-lg-block"><span class="font-lg"><i class="fa fa-caret-right text-danger"></i> Drop files <span class="font-xs">to upload</span></span><span>&nbsp&nbsp<h4 class="display-inline"> (Or Click)</h4></span>',
                      dictResponseError: 'Error uploading file!'
                    }}>
                      <form action="/upload" className="dropzone" id="file"/>
                    </DropzoneInput>
                    <span className="widget-icon"> <i className="fa fa-cloud-upload text-muted mb-3"/> </span>
                    </div>
                    
                 </div> 
                </div>                                              
            </div>
            
        )
        
    }
}