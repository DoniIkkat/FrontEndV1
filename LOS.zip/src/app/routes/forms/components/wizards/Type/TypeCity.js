import React from 'react'
import Jktcity from './Jktcity';
import BantenCity from './BantenCity';
import YogyaCity from './YogyaCity';
import BaliCity from './BaliCity';


export default class TypeCity extends React.Component{ 
    
    render(){ 

        if(this.props.DivState ==='DKI Jakarta'){
            return(
                <div>
                    <Jktcity
                       onChangeAddress= {this.props.onChangeAddress.bind(this)}
                    />
                </div>                
            );
        } else if(this.props.DivState ==='Banten'){ 
            return(
                <div>
                    <BantenCity
                        onChangeAddress= {this.props.onChangeAddress.bind(this)}
                    />
                    <br/>
                </div>                
            );
        } else if(this.props.DivState ==='Yogyakarta'){ 
            return(
                <div>
                    <YogyaCity
                        onChangeAddress= {this.props.onChangeAddress.bind(this)}
                    />
                    <br/>
                </div>                
            );
        }
        else if(this.props.DivState ==='Bali'){ 
            return(
                <div>
                    <BaliCity
                        onChangeAddress= {this.props.onChangeAddress.bind(this)}
                    />
                    <br/>
                </div>                
            );
        }  
        else { 
            return <div></div>
        } 

        
    }
}