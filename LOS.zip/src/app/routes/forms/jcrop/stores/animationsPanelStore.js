import {createStore} from 'redux'

import jcropReducer from '../reducers/jcropReducer'


export default createStore(jcropReducer)

