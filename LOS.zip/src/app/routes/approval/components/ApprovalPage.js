import React, {Component} from 'react' 

import BigBreadcrumbs from '../../../components/navigation/components/BigBreadcrumbs'  

import UiTabs from '../../../components/ui/UiTabs'
import All from './All'
import Filter from './Filter'
import Underwriting from './Underwriting'
import Rejected from './Rejected'
import Approved from './Approved'

export default class ApprovalPage extends React.Component {
  render() {
    return (
        <div id="content">
        <BigBreadcrumbs items={['Approval Page']}
                        className="col-xs-12 col-sm-7 col-md-7 col-lg-4"/> 
            <header>
              <div>
                <div className="widget-body">
                  <ul id="myTab1" className="nav nav-tabs bordered">
                    <li className="active, center">
                      <a className="center" href="#all" data-toggle="tab"><i className="fa fa-users"></i><span className="badge bg-color-blue txt-color-white">25</span><br/>All</a>
                    </li>
                    <li>
                      <a className="center"  href="#filter" data-toggle="tab"><i className="fa fa-users"></i><span className="badge bg-color-blue txt-color-white">4</span><br/>Filter</a>
                    </li>
                    <li>
                      <a className="center"  href="#underwriting" data-toggle="tab"><i className="fa fa-users"></i><span className="badge bg-color-blue txt-color-white">10</span><br/>Underwriting</a>
                    </li>
                    <li>
                      <a className="center"  href="#rejected" data-toggle="tab"><i className="fa fa-users"></i><span className="badge bg-color-blue txt-color-white">4</span><br/>Rejected</a>
                    </li>
                    <li>
                      <a className="center"  href="#approved" data-toggle="tab"><i className="fa fa-users"></i><span className="badge bg-color-blue txt-color-white">11</span><br/>Approved</a>
                    </li>

                  </ul>
                  <div id="myTabContent1" className="tab-content padding-10">
                    <div className="tab-pane fade in active" id="all">
                      <p>
                        <All/>
                      </p>
                    </div>
                    <div className="tab-pane fade" id="filter">
                      <p>
                        <Filter/>
                      </p>
                    </div>
                    <div className="tab-pane fade" id="underwriting">
                      <p>
                        <Underwriting/>
                      </p>
                    </div>
                    <div className="tab-pane fade" id="rejected">
                      <p>
                        <Rejected/>
                      </p>
                    </div>
                    <div className="tab-pane fade" id="approved">
                      <p>
                        <Approved/>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </header>
          

      </div>
    )
  }
}