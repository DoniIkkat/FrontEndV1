import React, {Component} from 'react';
import '../MenuTabs.css';

class tabs extends Component{
    
    render(){
        return(
            <div> 
            Document
            </div>
        )
    }
}

export default tabs;