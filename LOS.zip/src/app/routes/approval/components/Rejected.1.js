import React, {Component} from 'react';
import './MenuTabs.css';


class Rejected extends Component{
    render(){
        return(
          <div id="content">  
            empty
          </div>
        )
    }
}

export default Rejected;