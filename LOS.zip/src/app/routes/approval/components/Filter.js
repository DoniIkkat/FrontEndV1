import React, {Component} from 'react';
import './MenuTabs.css'
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css'
import 'react-bootstrap-table/dist/react-bootstrap-table.min.css'
import { Alert } from 'react-bootstrap';

import {WidgetGrid, JarvisWidget}  from '../../../components'

const reqreq = require('../../../../assets/api/tables/datatables.reqreq.json');
const filt = require('../../../../assets/api/tables/datatables.filt.json');

function onAfterSaveCell(row, cellName, cellValue) {
  console.log(`Save cell ${cellName} with value ${cellValue}`);
  console.log('The whole row :');
  console.log(row);
}

function onAfterInsertRow(row) {
    let newRowStr = '';
  
    for (const prop in row) {
      newRowStr += prop + ': ' + row[prop] + ' \n';
    }
    alert('The new row is:\n ' + newRowStr);
}

const cellEditProp = {
  mode: 'click',
  blurToSave: true,
  nonEditableRows: function() {
    return filt.filter(p => p.id < 1).map(p => p.id);
  },
  afterSaveCell: onAfterSaveCell
};
const optionally = {
  afterInsertRow: onAfterInsertRow   // A hook for after insert rows
};
const field = [ 'Gender'	, 'Age'	, 'Education'	, 'Marital Status'	, 'Current Address'	, 'House Ownership'	, 'Number of Children'	,  'Net Income'	,  'Own Credit Card'	,  'Collateral Value'	, 'National ID Number'	, 'Bankrupty Check'	, 'Defaults Check'	, 'Credit Bureau Inquiries'	, 'Credit Bureau Score'	, 'Active Loans'	, 'Delinquency Check'	, 'Income Type'];
const operand = [ '=', '>', '>=', '<', '<=', '!=' ];
const action = [ 'Pass','Reject','Refer' ];

class Filter extends Component{
  constructor(props) {
    super(props);
  }
    render(){
      const options = {
      };
        return(
            <div id="content">     
                          
                <div className="row">
                  <article className="col-sm-12">
      
                    <WidgetGrid><JarvisWidget editbutton={false} fullscreenbutton={false} deletebutton={false} color="blue">
                    <header><span className="widget-icon"> <i className="fa fa-table"/> </span> <h2>Filters </h2></header>
                    <div>
                      <div className="widget-body no-padding">

                      <BootstrapTable data={ reqreq }  striped={true} hover={true} condensed= {true} options={ optionally } cellEdit={ cellEditProp }
        options={ options } headerStyle={ { background: '#aaaadd' } }  containerStyle={ { background: '#FFFFFF' } } bodyStyle={ { background: '#ffffff' } }>
        
        <TableHeaderColumn dataField='field' width='25' dataAlign='center'  headerAlign='center' isKey={true}
        >Field</TableHeaderColumn>
        <TableHeaderColumn dataField='value' width='75' dataAlign='center'  headerAlign='center'
        >Value</TableHeaderColumn>
      </BootstrapTable>
                              
                      </div>
                    </div>
                  </JarvisWidget></WidgetGrid>
                  
                  </article>

                  
      
      
                </div>
                
            <Alert variant="warning" >Please click on the empty cells to start entering your desired Filters</Alert>
        <BootstrapTable data={ filt } insertRow={ true } options={ optionally } cellEdit={ cellEditProp } pagination={true} striped={true} hover={true} condensed= {true} search={true} 
        options={ options } headerStyle={ { background: '#aaaadd' } }  containerStyle={ { background: '#FFFFFF' } } bodyStyle={ { background: '#ffffff' } }
        searchPlaceholder='Search from any columns...'>
        <TableHeaderColumn dataField='no' width='0' dataAlign='center'  headerAlign='center'  isKey={ true } autoValue={true}
        >No</TableHeaderColumn>
        <TableHeaderColumn dataField='field' width='25' dataAlign='center'  headerAlign='center'
        editable={ { type: 'select', options: { values: field } } }
        >Field</TableHeaderColumn>
        <TableHeaderColumn dataField='operand' width='25' dataAlign='center'  headerAlign='center'
        editable={ { type: 'select', options: { values: operand } } }
        >Operand</TableHeaderColumn>
        <TableHeaderColumn dataField='value' width='25' dataAlign='center'  headerAlign='center'
        >Value</TableHeaderColumn>
        <TableHeaderColumn dataField='action' width='20' dataAlign='center'  headerAlign='center'
        editable={ { type: 'select', options: { values: action } } }
        >Action</TableHeaderColumn>
        <TableHeaderColumn dataField='description' width='155' dataAlign='center'  headerAlign='center'
        editable={ { type: 'textarea'} }
        >Description</TableHeaderColumn>
      </BootstrapTable>
            </div>
        )
    }
}

export default Filter;