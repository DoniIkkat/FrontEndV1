import React, {Component} from 'react';
import './MenuTabs.css'
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css'
import 'react-bootstrap-table/dist/react-bootstrap-table.min.css'
import { Tabs, Tab } from 'react-bootstrap';

//belum sempet dipake jadi ga ngaruh
import Riskscoring from './Minitab/riskscoring'
import Loan from './Minitab/loan'
import Personal from './Minitab/personal'
import Mainaddress from './Minitab/mainaddress'
import Additionaladdress from './Minitab/additionaladdress'
import Family from './Minitab/family'
import Business from './Minitab/business'
import Financial from './Minitab/financial'
import Bank from './Minitab/bank'
import Collateral from './Minitab/collateral'
import Document from './Minitab/document'

import {WidgetGrid, JarvisWidget}  from '../../../components'
import ReactSpeedometer from "react-d3-speedometer"

const datdata = require('../../../../assets/api/tables/datatables.datdata.json');
const status = [ 'On Process', 'Underwriting', 'temp' ];
function priceFormatter(cell, row) {
  return `IDR ${cell}`;
}
class AllTable extends Component{
    constructor(props) {
      super(props);
    }
  
    isExpandableRow(row) {
      if (row.id < 1000) return true;
      else return false;
    }
  
    expandComponent(row) {
      
      return (
        // <BSTable data={ row.expand } />
        <div>
          {/* cara memanggil menggunakan {row.namadata} misal row.id / row.fullName */}
        <Tabs defaultActiveKey="riskscoring" id="uncontrolled-tab-example"  className="lineblu">
          <Tab eventKey="riskscoring" title="Risk Scoring">
            {/* <Riskscoring/> */}
            {/* <div  className="exppa">
            <ReactSpeedometer
                                needleHeightRatio={0.7}
                                maxSegmentLabels={5} //label penomoran angka
                                segments={10} //label warna
                                segmentColors={["red", "red", "red", "yellow", "yellow", "green", "blue", "blue", "blue", "blue"]}
                                value={row.speedscore}
                                needleTransitionDuration={4000}
                                needleTransition="easeElastic"
                            />                     
             </div> */}
             <div className="sameline">  
             <div className="a50">
                <h1><b>Scoring Results</b></h1>
                <b>Score:</b> {row.speedscore}<br/>
                <b>Risk Level:</b> {row.status}   <br/>
                <b>System Decision:</b> {row.status}   <br/>
                <b>Odds:</b> {row.status}   <br/>
                <b>Probability of Default:</b> {row.status}%   <br/>
                <h1><b>Decision Comments</b></h1>
                <b>Scorecard Comments:</b> {row.status}    <br/>
                <b>Rule Engine Comments:</b> {row.status}    <br/>
             </div>
             {/* <div> &nbsp;  &nbsp;  &nbsp; </div> */}
             <div className="a51">
                <ReactSpeedometer
                    needleHeightRatio={0.7}
                    maxSegmentLabels={5} //label penomoran angka
                    segments={10} //label warna
                    segmentColors={["red", "red", "red", "yellow", "yellow", "green", "blue", "blue", "blue", "blue"]}
                    value={row.speedscore}
                    needleTransitionDuration={4000}
                    needleTransition="easeElastic"
                    width={250} height={250}
                />  
             </div>
             
            </div>
          </Tab>
          <Tab eventKey="loan" title="Loan">
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Loan Product</td><td>{row.loanProduct}</td></tr>
                <tr><td>Loan Amount</td><td>IDR {row.loanAmount}</td></tr>
                <tr><td>Purpose of Loan</td><td>{row.status}</td></tr>
                <tr><td>Tenor</td><td>{row.status}</td></tr>
              </table>
          </Tab>
          <Tab eventKey="personal" title="Personal">
            {/* <Personal /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Complete Name</td><td>{row.fullName}</td></tr>
                <tr><td>Mobile Phone</td><td>{row.mobilePhone}</td></tr>
                <tr><td>Landline</td><td>{row.status}</td></tr>
                <tr><td>ID Type</td><td>{row.idType}</td></tr>
                <tr><td>ID Number</td><td>{row.status}</td></tr>
                <tr><td>Place of Birth</td><td>{row.placeOfBirth}</td></tr>
                <tr><td>Date of Birth</td><td>{row.status}</td></tr>
                <tr><td>Gender</td><td>{row.gender}</td></tr>
                <tr><td>Education</td><td>{row.education}</td></tr>
                <tr><td>Marital Status</td><td>{row.maritalStatus}</td></tr>
                <tr><td>Email Address</td><td>{row.email}</td></tr>
              </table>
          </Tab>
          <Tab eventKey="mainaddress" title="Main Address">
            {/* <Mainaddress /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Current Address</td><td>{row.status}</td></tr>
                <tr><td>Province</td><td>{row.province}</td></tr>
                <tr><td>City</td><td>{row.city}</td></tr>
                <tr><td>District</td><td>{row.status}</td></tr>
                <tr><td>Postal</td><td>{row.status}</td></tr>
                <tr><td>Ownership Status</td><td>{row.status}</td></tr>
                <tr><td>Has been used as collateral elsewhere?</td><td>{row.status}</td></tr>
                <tr><td>Until</td><td>{row.status}</td></tr>
                <tr><td>Has lived in address since year</td><td>{row.status}</td></tr>
              </table>
          </Tab>
          <Tab eventKey="additionaladdress" title="Additional Address">
            {/* <Additionaladdress /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Address</td><td>{row.status}</td></tr>
                <tr><td>Province</td><td>{row.status}</td></tr>
                <tr><td>City</td><td>{row.status}</td></tr>
                <tr><td>District</td><td>{row.status}</td></tr>
                <tr><td>Postal</td><td>{row.status}</td></tr>
                <tr><td>Ownership Status</td><td>{row.status}</td></tr>
                <tr><td>Has been used as<br/>collateral elsewhere?</td><td>{row.status}</td></tr>
                <tr><td>Until</td><td>{row.status}</td></tr>
                <tr><td>Has lived in address since year</td><td>{row.status}</td></tr>
              </table>
          </Tab>
          <Tab eventKey="family" title="Family">
            {/* <Family /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Spouse Name</td><td>{row.status}</td></tr>
                <tr><td>Mobile Phone</td><td>{row.status}</td></tr>
                <tr><td>Place of Birth</td><td>{row.status}</td></tr>
                <tr><td>Date of Birth</td><td>{row.status}</td></tr>
                <tr><td>ID (KTP)</td><td>{row.status}</td></tr>
                <tr><td>Number of Children</td><td>{row.status}</td></tr>
                <tr><td>Emergency Contact</td><td>{row.status}</td></tr>
            </table>
          </Tab>
          <Tab eventKey="business" title="Business">
            {/* <Business /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Company</td><td>{row.status}</td></tr>
                <tr><td>Address</td><td>{row.status}</td></tr>
                <tr><td>Province</td><td>{row.status}</td></tr>
                <tr><td>City</td><td>{row.status}</td></tr>
                <tr><td>Division</td><td>{row.status}</td></tr>
                <tr><td>Duration</td><td>{row.status}</td></tr>
            </table>
          </Tab>
          <Tab eventKey="financial" title="Financial">
            {/* <Financial /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Income Type</td><td>{row.status}</td></tr>
                <tr><td>Main Income</td><td>{row.status}</td></tr>
                <tr><td>Side Income</td><td>{row.status}</td></tr>
                <tr><td>Expense</td><td>{row.status}</td></tr>
                <tr><td>Additional Expense</td><td>{row.status}</td></tr>
              </table>
          </Tab>
          <Tab eventKey="bank" title="Bank">
            {/* <Bank /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Bank</td><td>{row.status}</td></tr>
                <tr><td>Account Type</td><td>{row.status}</td></tr>
                <tr><td>Account Number</td><td>{row.status}</td></tr>
            </table>
          </Tab>
          <Tab eventKey="collateral" title="Collateral">
            {/* <Collateral /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Collateral Type</td><td>{row.status}</td></tr>
                <tr><td>Real Estate</td><td>{row.status}</td></tr>
            </table>
          </Tab>
          <Tab eventKey="document" title="Document">
            {/* <Document /> */}
            <table className="sumsum">
              <col width="50"/>
              <col width="200"/>
               <tr>
                  <th>Field</th><th>Value</th>
                </tr>
                <tr><td>Description</td><td>{row.status}</td></tr>
            </table>
          </Tab>
        </Tabs>
                       
         </div>
      );
    }

    render(){
        const options = {
          expandBy: 'column' //dan tiap kolom di expandable={false} maka supaya hanya (+) biar bisa expand
          //expandRowBgColor: 'rgb(255,255,255)'
        };
        const cellEdit = {
          mode: 'click',
          blurToSave: true
        };
        return(
            <div id="content"> 
             <WidgetGrid>
                    {/* row */}
                    <div className="row">
                        <article className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            {/* Widget ID (each widget will need unique ID)*/}
                            <JarvisWidget className="well" editbutton={false} fullscreenbutton={false} deletebutton={false} color="orange">

                                <header>
                                    <span className="widget-icon"> <i className="fa fa-comments"/> </span>

                                    <h2>All </h2>
                                </header>
                                {/* widget div*/}
                                <div>
                                    {/* widget content */}
                                    <div className="widget-body no-padding">                                    

                                    <BootstrapTable data={ datdata } pagination={true} striped={true} hover={true} condensed= {true} search={true} 
                                        options={ options } headerStyle={ { background: '#aaaadd' } }  cellEdit={ cellEdit }
                                        expandableRow={ this.isExpandableRow } containerStyle={ { background: '#FFFFFF' } }
                                        expandComponent={ this.expandComponent }  searchPlaceholder='Search from any columns...' 
                                        expandColumnOptions={ { expandColumnVisible: true } }>
                                        <TableHeaderColumn dataField='id' dataSort={true}  width='15%' dataAlign='center'  headerAlign='center' isKey={ true } 
                                          editable={ false } expandable={ false } filter={ { type: 'NumberFilter', delay: 10, } } 
                                        >Loan ID</TableHeaderColumn>
                                        <TableHeaderColumn dataField='fullName' dataSort={true}  width='20%' dataAlign='center'  headerAlign='center' 
                                          editable={ false } expandable={ false } filter={ { type: 'TextFilter', placeholder: 'Please enter a value', delay: 10 } }
                                        >Customer</TableHeaderColumn>
                                        <TableHeaderColumn dataField='loanAmount'   dataFormat={ priceFormatter } dataSort={true} width='15%' dataAlign='center'  headerAlign='center' 
                                          editable={ false } expandable={ false } filter={ { type: 'NumberFilter', delay: 10 } }
                                        >Loan</TableHeaderColumn>
                                        <TableHeaderColumn dataField='loanCreatedDate' dataAlign='center'  width='19%' headerAlign='center' 
                                          editable={ false } expandable={ false } filter={ { type: 'DateFilter', delay: 10, } } >Loan Created Date</TableHeaderColumn>
                                        <TableHeaderColumn dataField='waitingTime' dataAlign='center'  width='18%' headerAlign='center' editable={ false } expandable={ false }>Waiting Time</TableHeaderColumn>
                                        <TableHeaderColumn dataField='status' dataAlign='center'  width='13%' headerAlign='center' expandable={ false } editable={ { type: 'select', options: { values: status } } }>Status</TableHeaderColumn>
                                    </BootstrapTable>



                                    </div>
                                    {/* end widget content */}
                                </div>
                                {/* end widget div */}
                            </JarvisWidget>
                        </article>
                    </div>
                    {/* end row */}
                </WidgetGrid>
            </div>
        )
    }
}

export default AllTable;

