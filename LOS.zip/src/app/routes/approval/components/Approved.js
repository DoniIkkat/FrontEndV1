import React, {Component} from 'react';
import './MenuTabs.css';


class Approved extends Component{
    render(){
        return(
            <div id="content"> empty
            </div>
        )
    }
}

export default Approved;